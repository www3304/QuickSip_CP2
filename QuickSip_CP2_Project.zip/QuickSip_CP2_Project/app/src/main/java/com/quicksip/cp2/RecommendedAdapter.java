package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecommendedAdapter extends RecyclerView.Adapter<RecommendedAdapter.RecViewHolder> {

    public interface OnRecommendedClick {
        void onClick(DrinkItem item);
    }

    private List<DrinkItem> list;
    private OnRecommendedClick listener;

    public RecommendedAdapter(List<DrinkItem> list, OnRecommendedClick listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recommended_item, parent, false);
        return new RecViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecViewHolder holder, int position) {
        DrinkItem item = list.get(position);
        holder.tvName.setText(item.getName());
        holder.imgDrink.setImageResource(item.getImageResId());

        holder.itemView.setOnClickListener(v -> listener.onClick(item));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class RecViewHolder extends RecyclerView.ViewHolder {

        ImageView imgDrink;
        TextView tvName;

        public RecViewHolder(@NonNull View itemView) {
            super(itemView);
            imgDrink = itemView.findViewById(R.id.imgRecDrink);
            tvName = itemView.findViewById(R.id.tvRecName);
        }
    }
}
