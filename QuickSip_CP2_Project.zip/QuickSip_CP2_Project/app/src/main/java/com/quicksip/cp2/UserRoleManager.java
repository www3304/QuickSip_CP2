package com.quicksip.cp2;

import com.google.firebase.auth.FirebaseUser;
import java.util.Arrays;
import java.util.List;

public class UserRoleManager {

    private static final List<String> ADMIN_EMAILS = Arrays.asList(
            "admin@quicksip.com",
            "kitchen@quicksip.com"
    );

    public static boolean isAdmin(FirebaseUser user) {
        if (user == null || user.getEmail() == null) return false;
        return ADMIN_EMAILS.contains(user.getEmail().toLowerCase());
    }
}
