package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText etName, etEmail, etPassword, etConfirmPassword;
    Button btnRegister;
    TextView tvAlreadyHaveAccount;
    ProgressBar progressBar;

    FirebaseAuth auth;
    FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvAlreadyHaveAccount = findViewById(R.id.tvAlreadyHaveAccount);
        progressBar = findViewById(R.id.progressBarRegister);

        tvAlreadyHaveAccount.setOnClickListener(v ->
                startActivity(new Intent(RegisterActivity.this, MainActivity.class))
        );

        btnRegister.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // ❗ Validation
        if (name.isEmpty()) {
            etName.setError("Enter your name");
            return;
        }
        if (email.isEmpty()) {
            etEmail.setError("Email required");
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Invalid Email");
            return;
        }
        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            return;
        }
        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            return;
        }

        // Disable button to prevent double click
        btnRegister.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        // Firebase registration
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {

                    if (task.isSuccessful()) {

                        FirebaseUser user = auth.getCurrentUser();

                        // Save name to Firestore
                        if (user != null) {
                            Map<String, Object> userData = new HashMap<>();
                            userData.put("name", name);
                            userData.put("email", email);

                            firestore.collection("users")
                                    .document(user.getUid())
                                    .set(userData);
                        }

                        Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();

                        // Go to login page
                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                        finish();

                    } else {
                        Toast.makeText(this, "Failed: " +
                                task.getException().getMessage(), Toast.LENGTH_LONG).show();

                        btnRegister.setEnabled(true);
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }
}
