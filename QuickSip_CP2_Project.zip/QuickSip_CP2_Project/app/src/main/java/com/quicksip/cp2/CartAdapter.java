package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    public interface OnCartChangeListener {
        void onItemChanged();
    }

    private final List<CartItem> items;
    private final OnCartChangeListener listener;

    public CartAdapter(List<CartItem> items, OnCartChangeListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = items.get(position);

        holder.tvName.setText(item.getDrinkName());
        holder.tvOptions.setText(
                item.getSize() + " | " +
                        item.getIce() + " Ice | " +
                        item.getSugar() + " Sugar"
        );

        holder.tvQty.setText(String.valueOf(item.getQuantity()));
        holder.tvPrice.setText("RM " + String.format("%.2f", item.getFinalPrice()));

        holder.btnPlus.setOnClickListener(v -> {
            item.setQuantity(item.getQuantity() + 1);
            listener.onItemChanged();
            notifyItemChanged(position);
        });

        holder.btnMinus.setOnClickListener(v -> {
            int q = item.getQuantity() - 1;
            if (q <= 0) {
                items.remove(position);
                notifyItemRemoved(position);
            } else {
                item.setQuantity(q);
                notifyItemChanged(position);
            }
            listener.onItemChanged();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvOptions, tvQty, tvPrice;
        Button btnPlus, btnMinus;

        CartViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvOptions = itemView.findViewById(R.id.tvOptions);
            tvQty = itemView.findViewById(R.id.tvQty);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
        }
    }
}
