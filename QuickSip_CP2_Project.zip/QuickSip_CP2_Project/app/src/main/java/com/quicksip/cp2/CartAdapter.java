package com.quicksip.cp2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

// ✅ Import AndroidX AlertDialog
import androidx.appcompat.app.AlertDialog;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<CartItem> cartItemList;
    private OnCartChangeListener listener;

    public interface OnCartChangeListener {
        void onCartChanged();
    }

    public CartAdapter(List<CartItem> cartItemList, OnCartChangeListener listener) {
        this.cartItemList = cartItemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItemList.get(position);

        holder.tvName.setText(item.getName());
        double unitPrice = item.getFinalPrice();
        holder.tvPrice.setText("RM " + String.format("%.2f", unitPrice));
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));

        String details = item.getSize() + ", " + item.getSugar() + ", " + item.getIce();
        if (item.getToppings() != null && !item.getToppings().isEmpty()) {
            details += "\n+ " + item.getToppings();
        }
        holder.tvDetails.setText(details);

        Glide.with(holder.itemView.getContext())
                .load(item.getImageResId())
                .override(200, 200)
                .centerCrop()
                .into(holder.imgDrink);

        // Edit Button Logic
        holder.btnEdit.setOnClickListener(v -> {
            Context context = holder.itemView.getContext();
            Intent intent = new Intent(context, DrinkCustomizeActivity.class);

            intent.putExtra("drinkName", item.getName());
            intent.putExtra("drinkPrice", item.getBasePrice());
            intent.putExtra("drinkImage", item.getImageResId());

            // Edit Flags
            intent.putExtra("editIndex", position);
            intent.putExtra("editQty", item.getQuantity());
            intent.putExtra("editSize", item.getSize());
            intent.putExtra("editSugar", item.getSugar());
            intent.putExtra("editIce", item.getIce());
            intent.putExtra("editToppings", item.getToppings());

            if (item.getCategories() != null) {
                intent.putExtra("drinkCategories", item.getCategories().toArray(new String[0]));
            }

            context.startActivity(intent);
        });

        // Plus Button Logic
        holder.btnPlus.setOnClickListener(v -> {
            int newQty = item.getQuantity() + 1;
            item.setQuantity(newQty);
            holder.tvQuantity.setText(String.valueOf(newQty));
            updateCartItem(item);
            if (listener != null) listener.onCartChanged();
        });

        // Minus Button Logic (With Delete Confirmation)
        holder.btnMinus.setOnClickListener(v -> {
            int newQty = item.getQuantity() - 1;
            if (newQty > 0) {
                item.setQuantity(newQty);
                holder.tvQuantity.setText(String.valueOf(newQty));
                updateCartItem(item);
                if (listener != null) listener.onCartChanged();
            } else {
                // ✅ Show Confirmation Dialog before deleting
                showDeleteConfirmation(holder.itemView.getContext(), position);
            }
        });
    }

    private void showDeleteConfirmation(Context context, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Remove Item");
        builder.setMessage("Are you sure you want to remove this item?");

        builder.setPositiveButton("REMOVE", (d, which) -> {
            deleteCartItem(position);
            if (listener != null) listener.onCartChanged();
        });

        builder.setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        Button btnRemove = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button btnCancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);

        // Make Remove Button Solid Red (Since it is removing one item)
        // Or use "#00C853" if you want it green like the other one
        btnRemove.setBackgroundColor(Color.parseColor("#D32F2F")); // Red for danger
        btnRemove.setTextColor(Color.WHITE);

        // Make Cancel Button Transparent
        btnCancel.setBackgroundColor(Color.WHITE);
        btnCancel.setTextColor(Color.RED);

        // Add Spacing
        android.widget.LinearLayout.LayoutParams params = (android.widget.LinearLayout.LayoutParams) btnRemove.getLayoutParams();
        params.leftMargin = 30;
        btnRemove.setLayoutParams(params);
    }

    private void updateCartItem(CartItem item) {
        CartManager.getInstance().updateItem(item);
    }

    private void deleteCartItem(int position) {
        if (position >= 0 && position < cartItemList.size()) {
            cartItemList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, cartItemList.size());
            CartManager.getInstance().removeItem(position);
        }
    }

    @Override
    public int getItemCount() {
        return cartItemList.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPrice, tvQuantity, tvDetails;
        ImageView imgDrink;
        ImageButton btnMinus, btnPlus, btnEdit;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvCartItemName);
            tvPrice = itemView.findViewById(R.id.tvCartItemPrice);
            tvQuantity = itemView.findViewById(R.id.tvCartQuantity);
            tvDetails = itemView.findViewById(R.id.tvCartItemDetails);
            imgDrink = itemView.findViewById(R.id.imgCartItem);
            btnMinus = itemView.findViewById(R.id.btnCartMinus);
            btnPlus = itemView.findViewById(R.id.btnCartPlus);
            btnEdit = itemView.findViewById(R.id.btnEditCartItem);
        }
    }
}