package com.quicksip.cp2;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton; // ✅ Import ImageButton
import android.widget.TextView;
import android.widget.Toast; // ✅ Import Toast

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    public interface OnCartChangeListener {
        void onItemChanged();
    }

    private final List<CartItem> items;
    private final OnCartChangeListener listener;

    public CartAdapter(List<CartItem> items, OnCartChangeListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = items.get(position);

        holder.tvName.setText(item.getDrinkName());

        StringBuilder details = new StringBuilder();
        details.append(item.getSize());
        details.append(" | ").append(item.getIce()).append(" Ice");
        details.append(" | ").append(item.getSugar()).append(" Sugar");

        // Check if toppings exist and append them
        if (item.getToppings() != null && !item.getToppings().isEmpty()) {
            details.append(" | ").append(item.getToppings());
        }

        holder.tvOptions.setText(details.toString());

        holder.tvQty.setText(String.valueOf(item.getQuantity()));

        // Show Total Price for this item row (Price x Qty)
        double rowPrice = item.getFinalPrice() * item.getQuantity();
        holder.tvPrice.setText("RM " + String.format("%.2f", rowPrice));

        // Plus Button
        holder.btnPlus.setOnClickListener(v -> {
            item.setQuantity(item.getQuantity() + 1);
            listener.onItemChanged(); // Update Total in Activity
            notifyItemChanged(position);
        });

        // Minus Button
        holder.btnMinus.setOnClickListener(v -> {
            int q = item.getQuantity() - 1;
            if (q <= 0) {
                items.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, items.size()); // Sync indices
            } else {
                item.setQuantity(q);
                notifyItemChanged(position);
            }
            listener.onItemChanged(); // Update Total in Activity
        });

        // ✏Edit Button Logic
        holder.btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(holder.itemView.getContext(), DrinkCustomizeActivity.class);
            intent.putExtra("drinkName", item.getDrinkName());
            intent.putExtra("drinkPrice", item.getBasePrice());

            // Pass Existing Data
            intent.putExtra("editQty", item.getQuantity());
            intent.putExtra("editSize", item.getSize());
            intent.putExtra("editSugar", item.getSugar());
            intent.putExtra("editIce", item.getIce());
            intent.putExtra("editToppings", item.getToppings());

            intent.putExtra("editIndex", position);

            holder.itemView.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvOptions, tvQty, tvPrice;
        Button btnPlus, btnMinus;
        ImageButton btnEdit; // ✅ Added Edit Button

        CartViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvOptions = itemView.findViewById(R.id.tvOptions);
            tvQty = itemView.findViewById(R.id.tvQty);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnEdit = itemView.findViewById(R.id.btnEdit); // ✅ Find ID from XML
        }
    }
}