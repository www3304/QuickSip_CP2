package com.quicksip.cp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    TextInputLayout layoutEmail, layoutPassword;
    TextInputEditText etEmail, etPassword;
    TextView tvGoToRegister, tvForgotPassword;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Login layout

        Log.d("FIRESTORE", "MainActivity started");

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        auth = FirebaseAuth.getInstance();

        // 🔥 AUTO-LOGIN (Skip login if already authenticated)
        if (auth.getCurrentUser() != null) {
            redirectBasedOnAuth(auth.getCurrentUser());
            return;
        }

        layoutEmail = findViewById(R.id.layoutEmail);
        layoutPassword = findViewById(R.id.layoutPassword);

        etEmail = findViewById(R.id.etEmailLogin);
        etPassword = findViewById(R.id.etPasswordLogin);

        tvGoToRegister = findViewById(R.id.tvGoToRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        // ➜ Go to Register Page
        tvGoToRegister.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, RegisterActivity.class))
        );

        // ➜ Forgot Password
        tvForgotPassword.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ForgotPasswordActivity.class))
        );

        // ➜ Login Button
        findViewById(R.id.btnLogin).setOnClickListener(v -> loginUser());
    }

    private void loginUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        layoutEmail.setError(null);
        layoutPassword.setError(null);

        // VALIDATIONS
        if (email.isEmpty()) {
            layoutEmail.setError("Email required");
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            layoutEmail.setError("Invalid email format");
            return;
        }

        if (password.isEmpty()) {
            layoutPassword.setError("Password required");
            return;
        }
        if (password.length() < 6) {
            layoutPassword.setError("Minimum 6 characters");
            return;
        }

        // 🔥 Firebase Login
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        redirectBasedOnAuth(auth.getCurrentUser());
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Login failed: " + task.getException().getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    // 🔥 REDIRECT ADMIN/CUSTOMER
    private void redirectBasedOnAuth(com.google.firebase.auth.FirebaseUser user) {

        if (UserRoleManager.isAdmin(user)) {
            startActivity(new Intent(MainActivity.this, AdminDashboardActivity.class));
        } else {
            startActivity(new Intent(MainActivity.this, CustomerHomeActivity.class));
        }

        finish();
    }
}
