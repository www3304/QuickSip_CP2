package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View; // Needed for generic View clicks
import android.widget.Button; // For the Logout button
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AdminDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🔐 ADMIN PROTECTION
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (!UserRoleManager.isAdmin(user)) {
            Toast.makeText(this, "Access Denied: Admins Only", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin_dashboard);

        // 1. CLICK LISTENER FOR KITCHEN CARD (Active Orders)
        View cardKitchen = findViewById(R.id.cardKitchen);
        cardKitchen.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, KitchenOrdersActivity.class);
            startActivity(intent);
        });

        // 2. CLICK LISTENER FOR HISTORY CARD (Completed Orders)
        View cardHistory = findViewById(R.id.cardHistory);
        cardHistory.setOnClickListener(v -> {
            startActivity(new Intent(AdminDashboardActivity.this, AdminHistoryActivity.class));
        });

        // 3. LOGOUT BUTTON
        Button btnLogout = findViewById(R.id.btnAdminLogout);
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(AdminDashboardActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }
}