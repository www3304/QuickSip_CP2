package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.Date;

public class AdminDashboardActivity extends AppCompatActivity {

    // tvTotalCustomers
    private TextView tvTotalSales, tvTodaySales, tvTotalCustomers, tvPendingCount, tvDrinksSold, tvCompletedCount, tvCancelledCount;
    private FirebaseFirestore db;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        db = FirebaseFirestore.getInstance();

        // Init Views
        tvTotalSales = findViewById(R.id.tvTotalSales);
        tvTodaySales = findViewById(R.id.tvTodaySales);
        tvTotalCustomers = findViewById(R.id.tvTotalCustomers); // Bind new view
        tvPendingCount = findViewById(R.id.tvPendingCount);
        tvDrinksSold = findViewById(R.id.tvDrinksSold);
        tvCompletedCount = findViewById(R.id.tvCompletedCount);
        tvCancelledCount = findViewById(R.id.tvCancelledCount);
        bottomNav = findViewById(R.id.bottomNav);

        // Logout
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });

        // Navigation
        bottomNav.setSelectedItemId(R.id.nav_dashboard);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_kitchen) {
                startActivity(new Intent(this, KitchenOrdersActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (id == R.id.nav_history) {
                startActivity(new Intent(this, AdminHistoryActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return id == R.id.nav_dashboard;
        });

        calculateStats();
    }

    private void calculateStats() {
        // 1. Calculate Orders Stats
        db.collection("orders").get().addOnSuccessListener(snapshots -> {
            double totalRevenue = 0;
            double todayRevenue = 0;
            int pending = 0;
            int completed = 0;
            int cancelled = 0;
            int drinks = 0;

            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            Date startOfToday = cal.getTime();

            for (DocumentSnapshot doc : snapshots) {
                Order order = doc.toObject(Order.class);
                if (order == null) continue;

                String status = order.getStatus() != null ? order.getStatus().toUpperCase() : "NEW";

                if (!status.equals("COMPLETED") && !status.equals("CANCELLED")) {
                    pending++;
                }

                if (status.equals("COMPLETED")) completed++;
                if (status.equals("CANCELLED")) cancelled++;

                if (status.equals("COMPLETED")) {
                    totalRevenue += order.getTotalPrice();

                    if (order.getTimeStamp() != null) {
                        Date orderDate = order.getTimeStamp();
                        if (orderDate.after(startOfToday)) {
                            todayRevenue += order.getTotalPrice();
                        }
                    }

                    if (order.getItems() != null) {
                        for (CartItem item : order.getItems()) {
                            drinks += item.getQuantity();
                        }
                    }
                }
            }

            tvTotalSales.setText(String.format("RM %.2f", totalRevenue));
            tvTodaySales.setText(String.format("RM %.2f", todayRevenue));
            tvPendingCount.setText(String.valueOf(pending));
            tvDrinksSold.setText(String.valueOf(drinks));
            tvCompletedCount.setText(String.valueOf(completed));
            tvCancelledCount.setText(String.valueOf(cancelled));
        });

        // 2. NEW: Calculate Total Customers
        db.collection("users")
                .whereEqualTo("role", "customer")
                .get()
                .addOnSuccessListener(snapshots -> {
                    int customerCount = snapshots.size();
                    tvTotalCustomers.setText(String.valueOf(customerCount));
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        bottomNav.setSelectedItemId(R.id.nav_dashboard);
        calculateStats();
    }
}