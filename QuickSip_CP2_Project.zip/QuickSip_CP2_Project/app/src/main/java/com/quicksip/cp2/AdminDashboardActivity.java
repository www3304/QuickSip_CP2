package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AdminDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🔐 ADMIN PROTECTION
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (!UserRoleManager.isAdmin(user)) {
            Toast.makeText(this, "Access Denied: Admins Only", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin_dashboard);

        // 1. Button to Open Kitchen (Active Orders)
        Button btnKitchen = findViewById(R.id.btnKitchenOrders);
        btnKitchen.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, KitchenOrdersActivity.class);
            startActivity(intent);
        });

        // 2. Button to Logout
        Button btnLogout = findViewById(R.id.btnAdminLogout);
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(AdminDashboardActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        // 3. Button to Orders History
        Button btnHistory = findViewById(R.id.btnOrderHistory);
        btnHistory.setOnClickListener(v -> {
            startActivity(new Intent(AdminDashboardActivity.this, AdminHistoryActivity.class));
        });

        // to view only orders where status == "COMPLETED"
    }
}