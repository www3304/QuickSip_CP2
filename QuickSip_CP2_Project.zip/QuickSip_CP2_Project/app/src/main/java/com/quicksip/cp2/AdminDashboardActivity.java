package com.quicksip.cp2;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

// 🔥 THIS WAS MISSING
import com.quicksip.cp2.Order;

import java.util.ArrayList;
import java.util.List;

public class AdminDashboardActivity extends AppCompatActivity {

    private RecyclerView activeOrderRecycler, completedOrderRecycler;
    private OrderAdapter activeAdapter, completedAdapter;

    private List<Order> activeOrders = new ArrayList<>();
    private List<Order> completedOrders = new ArrayList<>();

    private Button btnKitchenOrders;          // ⬅️ NEW

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 🔐 ADMIN PROTECTION
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (!UserRoleManager.isAdmin(user)) {
            finish(); // block non-admin access
            return;
        }

        setContentView(R.layout.activity_admin_dashboard);

        Button btnLogout = findViewById(R.id.btnAdminLogout);

        btnLogout.setOnClickListener(v -> {
            // 🔐 Firebase logout
            FirebaseAuth.getInstance().signOut();

            // 🔁 Go back to Login page
            Intent intent = new Intent(AdminDashboardActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            finish(); // close admin page
        });

        Button btnKitchen = findViewById(R.id.btnKitchenOrders);
        btnKitchen.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, KitchenOrdersActivity.class);
            startActivity(intent);
        });

        activeOrderRecycler = findViewById(R.id.activeOrderRecycler);
        completedOrderRecycler = findViewById(R.id.completedOrderRecycler);
        btnKitchenOrders = findViewById(R.id.btnKitchenOrders);   // ⬅️ NEW

        // open Kitchen screen
        btnKitchenOrders.setOnClickListener(v -> {
            Intent i = new Intent(AdminDashboardActivity.this, KitchenOrdersActivity.class);
            startActivity(i);
        });

        activeOrderRecycler.setLayoutManager(new LinearLayoutManager(this));
        completedOrderRecycler.setLayoutManager(new LinearLayoutManager(this));

        splitOrders();

        // -----------------------
        // ADAPTERS
        // -----------------------
        activeAdapter = new OrderAdapter(activeOrders, new OrderAdapter.OnStatusChangeListener() {
            @Override
            public void onStatusChange(int position, String newStatus) {
                Order order = activeOrders.get(position);
                order.setStatus(newStatus);

                // Move to completed list
                if (newStatus.equals("COMPLETED")) {
                    completedOrders.add(order);
                    activeOrders.remove(position);
                    completedAdapter.notifyItemInserted(completedOrders.size() - 1);
                }
                activeAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancel(int position) {
                activeOrders.remove(position);
                activeAdapter.notifyItemRemoved(position);
            }
        });

        completedAdapter = new OrderAdapter(completedOrders, new OrderAdapter.OnStatusChangeListener() {
            @Override
            public void onStatusChange(int position, String newStatus) {
                // Completed orders do not change status
            }

            @Override
            public void onCancel(int position) {
                completedOrders.remove(position);
                completedAdapter.notifyItemRemoved(position);
            }
        });

        activeOrderRecycler.setAdapter(activeAdapter);
        completedOrderRecycler.setAdapter(completedAdapter);

        // -----------------------
        // SWIPE DELETE for BOTH
        // -----------------------
        enableSwipeToDelete(activeOrderRecycler, activeOrders, activeAdapter);
        enableSwipeToDelete(completedOrderRecycler, completedOrders, completedAdapter);
    }

    private void splitOrders() {
        List<Order> allOrders = OrderManager.getInstance().getOrders();

        activeOrders.clear();
        completedOrders.clear();

        for (Order order : allOrders) {
            if (order.getStatus().equals("COMPLETED")) {
                completedOrders.add(order);
            } else {
                activeOrders.add(order);
            }
        }
    }

    private void enableSwipeToDelete(RecyclerView recyclerView, List<Order> list, OrderAdapter adapter) {

        ItemTouchHelper.SimpleCallback callback =
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {

                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView,
                                          @NonNull RecyclerView.ViewHolder viewHolder,
                                          @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        int pos = viewHolder.getAdapterPosition();
                        list.remove(pos);
                        adapter.notifyItemRemoved(pos);
                    }

                    @Override
                    public void onChildDraw(@NonNull Canvas c,
                                            @NonNull RecyclerView recyclerView,
                                            @NonNull RecyclerView.ViewHolder viewHolder,
                                            float dX, float dY,
                                            int actionState, boolean isCurrentlyActive) {

                        super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);

                        View itemView = viewHolder.itemView;

                        Paint paint = new Paint();
                        paint.setColor(Color.parseColor("#E53935")); // red background

                        if (dX < 0) { // user swiping left
                            c.drawRect(
                                    itemView.getRight() + dX,
                                    itemView.getTop(),
                                    itemView.getRight(),
                                    itemView.getBottom(),
                                    paint
                            );

                            Drawable icon = ContextCompat.getDrawable(
                                    recyclerView.getContext(),
                                    R.drawable.ic_delete  // must be in drawable
                            );

                            int iconSize = 80;
                            int iconTop = itemView.getTop() + (itemView.getHeight() - iconSize) / 2;
                            int iconLeft = itemView.getRight() - iconSize - 40;
                            int iconRight = itemView.getRight() - 40;
                            int iconBottom = iconTop + iconSize;

                            if (icon != null) {
                                icon.setBounds(iconLeft, iconTop, iconRight, iconBottom);
                                icon.draw(c);
                            }
                        }
                    }
                };

        new ItemTouchHelper(callback).attachToRecyclerView(recyclerView);
    }
}
