package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.DrinkViewHolder> {

    private List<DrinkItem> drinkList;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(DrinkItem item);
    }

    public DrinkAdapter(List<DrinkItem> drinkList, OnItemClickListener listener) {
        this.drinkList = drinkList;
        this.listener = listener;
    }

    public void filterList(List<DrinkItem> filteredList) {
        this.drinkList = filteredList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DrinkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_drink, parent, false);
        return new DrinkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkViewHolder holder, int position) {
        // Renamed variable to 'item' so the rest of the code works
        DrinkItem item = drinkList.get(position);

        holder.tvName.setText(item.getName());

        holder.tvDesc.setText(item.getDescription());

        holder.tvPrice.setText("RM " + String.format("%.2f", item.getPrice()));

        Glide.with(holder.itemView.getContext())
                .load(item.getImageResId())
                .override(300, 300)
                .centerCrop()
                .into(holder.imgDrink);

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
        holder.btnAdd.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return drinkList.size();
    }

    public static class DrinkViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDesc, tvPrice;
        ImageView imgDrink;
        ImageButton btnAdd;

        public DrinkViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvDrinkName);
            tvDesc = itemView.findViewById(R.id.tvDrinkDesc);
            tvPrice = itemView.findViewById(R.id.tvDrinkPrice);
            imgDrink = itemView.findViewById(R.id.imgDrink);
            btnAdd = itemView.findViewById(R.id.btnAdd);
        }
    }
}