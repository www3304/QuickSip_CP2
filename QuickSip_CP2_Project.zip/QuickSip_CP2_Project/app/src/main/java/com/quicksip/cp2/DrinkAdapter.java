package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide; // Import Glide

import java.util.List;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.DrinkViewHolder> {

    private List<DrinkItem> drinkList;
    private final OnItemClickListener listener;

    // Interface for click events
    public interface OnItemClickListener {
        void onItemClick(DrinkItem item);
    }

    // Constructor
    public DrinkAdapter(List<DrinkItem> drinkList, OnItemClickListener listener) {
        this.drinkList = drinkList;
        this.listener = listener;
    }

    public void filterList(List<DrinkItem> filteredList) {
        this.drinkList = filteredList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DrinkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_drink, parent, false);
        return new DrinkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkViewHolder holder, int position) {
        DrinkItem drink = drinkList.get(position);

        holder.tvName.setText(drink.getName());

        // Handle Description (Optional: hide if null)
        holder.tvDesc.setText("Rich tea leaves with creamy milk");

        holder.tvPrice.setText("RM " + String.format("%.2f", drink.getPrice()));

        // ✅ FIXED: Use Glide to load image (Prevents Crash)
        Glide.with(holder.itemView.getContext())
                .load(drink.getImageResId())
                .override(300, 300) // Resize to save memory
                .centerCrop()
                .into(holder.imgDrink);

        // ✅ Click Listeners
        holder.itemView.setOnClickListener(v -> listener.onItemClick(drink));

        // This fixes the "cannot find symbol btnAdd" error
        holder.btnAdd.setOnClickListener(v -> listener.onItemClick(drink));
    }

    @Override
    public int getItemCount() {
        return drinkList.size();
    }

    // ✅ ViewHolder Class
    public static class DrinkViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDesc, tvPrice;
        ImageView imgDrink;
        ImageButton btnAdd; // Defined here

        public DrinkViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvDrinkName);
            tvDesc = itemView.findViewById(R.id.tvDrinkDesc); // Ensure ID matches XML
            tvPrice = itemView.findViewById(R.id.tvDrinkPrice);
            imgDrink = itemView.findViewById(R.id.imgDrink);
            btnAdd = itemView.findViewById(R.id.btnAdd); // Ensure ID matches XML
        }
    }
}