package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.DrinkViewHolder> {

    public interface OnDrinkClickListener {
        void onDrinkClick(DrinkItem item);
    }

    private List<DrinkItem> drinkList;
    private OnDrinkClickListener listener;

    public DrinkAdapter(List<DrinkItem> drinkList, OnDrinkClickListener listener) {
        this.drinkList = drinkList;
        this.listener = listener;
    }
    public void filterList(List<DrinkItem> filteredList) {
        this.drinkList = filteredList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DrinkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_drink, parent, false);
        return new DrinkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkViewHolder holder, int position) {
        DrinkItem item = drinkList.get(position);

        holder.tvName.setText(item.getName());
        holder.tvPrice.setText("RM " + item.getPrice());

        // ✅ SAFE image handling (VERY IMPORTANT)
        if (item.getImageResId() != 0) {
            holder.imgDrink.setImageResource(item.getImageResId());
        } else {
            holder.imgDrink.setImageDrawable(null);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDrinkClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return drinkList.size();
    }

    public static class DrinkViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPrice;
        ImageView imgDrink;

        public DrinkViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvDrinkName);
            tvPrice = itemView.findViewById(R.id.tvDrinkPrice);
            imgDrink = itemView.findViewById(R.id.imgDrink);
        }
    }
}
