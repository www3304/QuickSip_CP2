package com.quicksip.cp2;

import android.util.Log;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FieldValue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FirestoreOrderManager {

    private static FirestoreOrderManager instance;
    private final FirebaseFirestore db;

    private FirestoreOrderManager() {
        db = FirebaseFirestore.getInstance();
    }

    public static FirestoreOrderManager getInstance() {
        if (instance == null) {
            instance = new FirestoreOrderManager();
        }
        return instance;
    }

    public void saveOrder(Order order, String userId) {

        Log.d("FIRESTORE_TEST", "saveOrder() called");
        Log.d("FIRESTORE_TEST", "OrderId = " + order.getOrderId());
        Log.d("FIRESTORE_TEST", "UserId = " + userId);

        Map<String, Object> data = new HashMap<>();
        data.put("orderId", order.getOrderId());
        data.put("userId", userId);
        data.put("status", order.getStatus());
        data.put("totalPrice", order.getTotalPrice());
        data.put("timestamp", FieldValue.serverTimestamp());

        // IMPORTANT: do NOT store CartItem list yet
        data.put("items", order.getItems());

        db.collection("orders")
                .document(order.getOrderId())
                .set(data)
                .addOnSuccessListener(aVoid ->
                        Log.d("FIRESTORE_TEST", "Order saved to Firestore SUCCESS"))
                .addOnFailureListener(e ->
                        Log.e("FIRESTORE_TEST", "Firestore ERROR", e));
    }
}
