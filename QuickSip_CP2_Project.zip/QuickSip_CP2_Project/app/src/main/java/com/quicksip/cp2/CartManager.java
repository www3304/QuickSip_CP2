package com.quicksip.cp2;

import java.util.ArrayList;
import java.util.List;

public class CartManager {

    private static CartManager instance;
    private final List<CartItem> cartList = new ArrayList<>();

    private CartManager() {}

    public static CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    // 🔥 Add item but auto-merge identical drinks
    public void addOrMerge(CartItem newItem) {

        for (CartItem item : cartList) {

            boolean sameDrink =
                    item.getDrinkName().equals(newItem.getDrinkName()) &&
                            item.getSize().equals(newItem.getSize()) &&
                            item.getIce().equals(newItem.getIce()) &&
                            item.getSugar().equals(newItem.getSugar()) &&
                            item.getToppings().equals(newItem.getToppings());

            if (sameDrink) {
                item.increaseQty();
                return;
            }
        }

        cartList.add(newItem);
    }

    // 🔁 Backward compatibility
    public void addToCart(CartItem item) {
        addOrMerge(item);
    }

    // ✅ REQUIRED by CartActivity
    public List<CartItem> getItems() {
        return cartList;
    }

    // ✅ REQUIRED by CartActivity
    public void clear() {
        cartList.clear();
    }

    // ✅ REQUIRED by CartActivity
    public double getTotalPrice() {
        double total = 0;
        for (CartItem item : cartList) {
            total += item.getFinalPrice() * item.getQuantity();
        }
        return total;
    }

    public void removeItem(int index) {
        if (index >= 0 && index < cartList.size()) {
            cartList.remove(index);
        }
    }
}
