package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CheckoutAdapter extends RecyclerView.Adapter<CheckoutAdapter.CheckoutViewHolder> {

    private final List<CartItem> items;

    public CheckoutAdapter(List<CartItem> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public CheckoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_checkout, parent, false);
        return new CheckoutViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CheckoutViewHolder holder, int position) {
        CartItem item = items.get(position);

        holder.tvName.setText(item.getName());
        holder.tvQuantity.setText(item.getQuantity() + "x");
        holder.tvPrice.setText("RM " + String.format("%.2f", item.getFinalPrice() * item.getQuantity()));

        // Format details (Size, Ice, Sugar)
        String details = item.getSize() + " | Ice: " + item.getIce() + " | Sugar: " + item.getSugar();
        holder.tvDetails.setText(details);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class CheckoutViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvQuantity, tvPrice, tvDetails;

        public CheckoutViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvCheckoutName);
            tvQuantity = itemView.findViewById(R.id.tvCheckoutQty);
            tvPrice = itemView.findViewById(R.id.tvCheckoutPrice);
            tvDetails = itemView.findViewById(R.id.tvCheckoutDetails);
        }
    }
}