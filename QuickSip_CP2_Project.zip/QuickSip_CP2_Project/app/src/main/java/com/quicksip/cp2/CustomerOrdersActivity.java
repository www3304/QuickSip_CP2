package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class CustomerOrdersActivity extends AppCompatActivity {

    private RecyclerView ordersRecycler;
    private CustomerOrderAdapter adapter;
    private final List<Order> orders = new ArrayList<>();
    private ImageView imgEmptyOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_orders);

        // Header Back Button
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(CustomerOrdersActivity.this, CustomerHomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        // ---------------------------------------------------------
        // 🚀 BOTTOM NAVIGATION LOGIC (Added)
        // ---------------------------------------------------------

        // 1. Home Button -> Go to Home
        findViewById(R.id.navHome).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerHomeActivity.class));
            overridePendingTransition(0, 0); // No animation (smooth tab switch)
            finish();
        });

        // 2. My Orders Button -> Already here (Do nothing)
        findViewById(R.id.navMyOrders).setOnClickListener(v -> {
            // Stay on this page
        });

        // 3. Profile Button -> Go to Profile
        findViewById(R.id.navProfile).setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        // ---------------------------------------------------------

        // Setup Views
        ordersRecycler = findViewById(R.id.ordersRecycler);
        imgEmptyOrders = findViewById(R.id.imgEmptyOrders);

        if (ordersRecycler == null) {
            Log.e("QuickSip", "CRITICAL ERROR: ordersRecycler ID not found in XML!");
        }

        ordersRecycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CustomerOrderAdapter(orders);
        ordersRecycler.setAdapter(adapter);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "Error: User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadOrders(user.getUid());
    }

    private void loadOrders(String userId) {
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereEqualTo("userId", userId)
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                // 🔥 FIX: Add 'this' as the first parameter here
                .addSnapshotListener(this, (snapshots, e) -> {
                    if (e != null) {
                        // Permissions error will still happen if you logout,
                        // but 'this' minimizes how long it stays alive.
                        // We can also just ignore permission errors to keep logs clean:
                        if (e.getCode() == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                            return;
                        }
                        Log.e("QuickSip", "Listen failed.", e);
                        return;
                    }

                    if (snapshots == null) return;

                    orders.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        try {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setFirestoreId(doc.getId());
                                orders.add(order);
                            }
                        } catch (Exception ex) {
                            Log.e("QuickSip", "SKIPPING CORRUPT ORDER: " + doc.getId(), ex);
                        }
                    }

                    toggleEmptyState();
                    adapter.notifyDataSetChanged();
                });
    }

    private void toggleEmptyState() {
        if (ordersRecycler == null) return;

        if (orders.isEmpty()) {
            ordersRecycler.setVisibility(View.GONE);
            if (imgEmptyOrders != null) {
                imgEmptyOrders.setVisibility(View.VISIBLE);
            }
        } else {
            ordersRecycler.setVisibility(View.VISIBLE);
            if (imgEmptyOrders != null) {
                imgEmptyOrders.setVisibility(View.GONE);
            }
        }
    }
}