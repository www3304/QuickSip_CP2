package com.quicksip.cp2;

import android.os.Bundle;
import android.widget.Toast;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class CustomerOrdersActivity extends AppCompatActivity {

    private RecyclerView ordersRecycler;
    private CustomerOrderAdapter adapter;
    private final List<Order> orders = new ArrayList<>();

    // 🎨 Define the variable
    private ImageView imgEmptyOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_orders);

        ordersRecycler = findViewById(R.id.ordersRecycler);

        // 🎨 Find the ImageView
        imgEmptyOrders = findViewById(R.id.imgEmptyOrders);

        ordersRecycler.setLayoutManager(new LinearLayoutManager(this));

        adapter = new CustomerOrderAdapter(orders);
        ordersRecycler.setAdapter(adapter);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereEqualTo("userId", user.getUid())
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    orders.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            // ✅ Fix 1: Ensure Firestore ID is set
                            order.setFirestoreId(doc.getId());
                            orders.add(order);
                        }
                    }

                    // 🎨 Fix 2: Toggle Empty State Logic
                    if (orders.isEmpty()) {
                        ordersRecycler.setVisibility(View.GONE);
                        imgEmptyOrders.setVisibility(View.VISIBLE); // Show Image
                    } else {
                        ordersRecycler.setVisibility(View.VISIBLE); // Show List
                        imgEmptyOrders.setVisibility(View.GONE);
                    }

                    adapter.notifyDataSetChanged();
                });
    }
}
