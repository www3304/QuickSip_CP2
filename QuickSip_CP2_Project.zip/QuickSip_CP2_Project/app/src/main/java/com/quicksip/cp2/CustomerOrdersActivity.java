package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomerOrdersActivity extends AppCompatActivity {

    private RecyclerView ordersRecycler;
    private OrderAdapter adapter;
    private List<Order> orderList;
    private FirebaseFirestore db;
    private LinearLayout emptyStateLayout;
    private String userId;
    private ListenerRegistration ordersListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_orders);

        // 1. Initialize Firebase
        db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user != null) {
            userId = user.getUid();
        } else {
            Toast.makeText(this, "Please login to view orders", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 2. Initialize Views
        ordersRecycler = findViewById(R.id.ordersRecycler);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);

        // SETUP TOP BACK BUTTON
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // SETUP BOTTOM NAVIGATION
        // Home Button
        View navHome = findViewById(R.id.navHome);
        if (navHome != null) {
            navHome.setOnClickListener(v -> {
                startActivity(new Intent(this, CustomerHomeActivity.class));
                overridePendingTransition(0, 0); // Smooth transition
                finish();
            });
        }

        // Profile Button
        View navProfile = findViewById(R.id.navProfile);
        if (navProfile != null) {
            navProfile.setOnClickListener(v -> {
                startActivity(new Intent(this, ProfileActivity.class));
                overridePendingTransition(0, 0);
                finish();
            });
        }

        // 3. Setup List
        ordersRecycler.setLayoutManager(new LinearLayoutManager(this));
        orderList = new ArrayList<>();

        // Pass 'null' listener to hide Admin buttons
        adapter = new OrderAdapter(orderList, null);
        ordersRecycler.setAdapter(adapter);

        // 4. Load Data
        loadOrders();
    }

    private void loadOrders() {
        if (userId == null) return;

        ordersListener = db.collection("orders")
                .whereEqualTo("userId", userId)
                .addSnapshotListener((value, error) -> {
                    if (error != null) return;

                    if (value != null) {
                        orderList.clear();
                        for (DocumentSnapshot doc : value.getDocuments()) {
                            Order order = doc.toObject(Order.class);
                            Log.d("DEBUG_ORDER", "ID: " + doc.getId() + " | Price: " + order.getTotalPrice() + " | Items: " + (order.getItems() != null ? order.getItems().size() : "NULL"));
                            if (order != null) {
                                order.setOrderId(doc.getId());
                                orderList.add(order);
                            }
                        }

                        // SORT: New -> Preparing -> Ready -> Completed
                        Collections.sort(orderList, (o1, o2) -> {
                            int rank1 = getStatusRank(o1.getStatus());
                            int rank2 = getStatusRank(o2.getStatus());
                            if (rank1 != rank2) return rank1 - rank2;
                            return o2.getOrderId().compareTo(o1.getOrderId());
                        });

                        adapter.notifyDataSetChanged();
                        updateEmptyState();
                    }
                });
    }

    private int getStatusRank(String status) {
        if (status == null) return 5;
        switch (status.toUpperCase()) {
            case "NEW": return 1;
            case "PREPARING": return 2;
            case "READY": return 3;
            case "COMPLETED": return 4;
            default: return 5;
        }
    }

    private void updateEmptyState() {
        if (orderList.isEmpty()) {
            ordersRecycler.setVisibility(View.GONE);
            if (emptyStateLayout != null) emptyStateLayout.setVisibility(View.VISIBLE);
        } else {
            ordersRecycler.setVisibility(View.VISIBLE);
            if (emptyStateLayout != null) emptyStateLayout.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ordersListener != null) ordersListener.remove();
    }
}