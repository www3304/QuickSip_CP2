package com.quicksip.cp2;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class CustomerOrdersActivity extends AppCompatActivity {

    private RecyclerView ordersRecycler;
    private CustomerOrderAdapter adapter;
    private final List<Order> orders = new ArrayList<>();
    private ImageView imgEmptyOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_orders);

        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish()); // Simply closes current screen
        }

        // 1. Setup Views with Safety Checks
        ordersRecycler = findViewById(R.id.ordersRecycler);
        imgEmptyOrders = findViewById(R.id.imgEmptyOrders);

        if (ordersRecycler == null) {
            Log.e("QuickSip", "CRITICAL ERROR: ordersRecycler ID not found in XML!");
        }

        // 2. Setup RecyclerView
        ordersRecycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CustomerOrderAdapter(orders);
        ordersRecycler.setAdapter(adapter);

        // 3. Get Current User
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "Error: User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        // 4. Load Data Safely
        loadOrders(user.getUid());
    }

    private void loadOrders(String userId) {
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereEqualTo("userId", userId)
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.e("QuickSip", "Listen failed.", e);
                        return;
                    }

                    if (snapshots == null) return;

                    orders.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        try {
                            // 🛡️ TRY-CATCH BLOCK: Ignores bad data instead of crashing
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setFirestoreId(doc.getId());
                                orders.add(order);
                            }
                        } catch (Exception ex) {
                            Log.e("QuickSip", "SKIPPING CORRUPT ORDER: " + doc.getId(), ex);
                        }
                    }

                    // 5. Toggle Empty State (Safe Version)
                    toggleEmptyState();

                    adapter.notifyDataSetChanged();
                });
    }

    private void toggleEmptyState() {
        // 🛡️ Safe Check: Only try to toggle views if they exist
        if (ordersRecycler == null) return;

        if (orders.isEmpty()) {
            ordersRecycler.setVisibility(View.GONE);
            if (imgEmptyOrders != null) {
                imgEmptyOrders.setVisibility(View.VISIBLE);
            }
        } else {
            ordersRecycler.setVisibility(View.VISIBLE);
            if (imgEmptyOrders != null) {
                imgEmptyOrders.setVisibility(View.GONE);
            }
        }
    }
}