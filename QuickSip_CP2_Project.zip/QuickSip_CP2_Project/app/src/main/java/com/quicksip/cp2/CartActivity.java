package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView cartRecycler;
    private TextView tvTotal;
    private Button btnCheckout;

    private CartAdapter adapter;
    private List<CartItem> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cartRecycler = findViewById(R.id.cartRecycler);
        tvTotal = findViewById(R.id.tvTotal);
        btnCheckout = findViewById(R.id.btnCheckout);

        cartItems = CartManager.getInstance().getItems();

        // ✅ NEW CartAdapter usage
        adapter = new CartAdapter(cartItems, this::updateTotal);

        cartRecycler.setLayoutManager(new LinearLayoutManager(this));
        cartRecycler.setAdapter(adapter);

        updateTotal();

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }

            startActivity(new Intent(this, CheckoutActivity.class));
        });
    }

    private void updateTotal() {
        double total = CartManager.getInstance().getTotalPrice();
        tvTotal.setText("Total: RM " + String.format("%.2f", total));

        // 🎨 NEW: Toggle Empty State
        ImageView imgEmpty = findViewById(R.id.imgEmptyCart);
        if (cartItems.isEmpty()) {
            cartRecycler.setVisibility(View.GONE);
            imgEmpty.setVisibility(View.VISIBLE);
        } else {
            cartRecycler.setVisibility(View.VISIBLE);
            imgEmpty.setVisibility(View.GONE);
        }
    }
}
