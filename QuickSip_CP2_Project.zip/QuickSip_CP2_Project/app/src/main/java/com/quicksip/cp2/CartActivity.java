package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton; // Correct import
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView cartRecycler;
    private CartAdapter adapter;
    private TextView tvTotal;
    private Button btnCheckout;
    private ImageView imgEmptyCart;
    private ImageButton btnClearCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // 1. SETUP HEADER BUTTONS
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        btnClearCart = findViewById(R.id.btnClearCart);
        btnClearCart.setOnClickListener(v -> {
            CartManager.getInstance().clear();
            updateUI();
            Toast.makeText(this, "Cart cleared", Toast.LENGTH_SHORT).show();
        });

        // 2. SETUP VIEWS
        cartRecycler = findViewById(R.id.cartRecycler);
        tvTotal = findViewById(R.id.tvTotal);
        btnCheckout = findViewById(R.id.btnCheckout);
        imgEmptyCart = findViewById(R.id.imgEmptyCart);

        cartRecycler.setLayoutManager(new LinearLayoutManager(this));

        // 3. LOAD DATA
        updateUI();

        // 4. CHECKOUT LOGIC
        btnCheckout.setOnClickListener(v -> {
            if (CartManager.getInstance().getItems().isEmpty()) {
                Toast.makeText(this, "Cart is empty!", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(CartActivity.this, CheckoutActivity.class));
        });
    }

    private void updateUI() {
        List<CartItem> items = CartManager.getInstance().getItems();
        double total = CartManager.getInstance().getTotalPrice();

        if (items.isEmpty()) {
            cartRecycler.setVisibility(View.GONE);
            imgEmptyCart.setVisibility(View.VISIBLE);
            btnCheckout.setEnabled(false);
            btnCheckout.setAlpha(0.5f);
        } else {
            cartRecycler.setVisibility(View.VISIBLE);
            imgEmptyCart.setVisibility(View.GONE);
            btnCheckout.setEnabled(true);
            btnCheckout.setAlpha(1.0f);
        }

        // Setup Adapter with Listener to update total when qty changes
        adapter = new CartAdapter(items, new CartAdapter.OnCartChangeListener() {
            @Override
            public void onItemChanged() {
                tvTotal.setText("RM " + String.format("%.2f", CartManager.getInstance().getTotalPrice()));
                // If cart becomes empty after deleting last item:
                if (CartManager.getInstance().getItems().isEmpty()) {
                    updateUI();
                }
            }
        });
        cartRecycler.setAdapter(adapter);

        tvTotal.setText("RM " + String.format("%.2f", total));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update UI when returning from Checkout (in case cart was cleared)
        updateUI();
    }
}