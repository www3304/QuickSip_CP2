package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView cartRecycler;
    private CartAdapter adapter;
    private TextView tvTotal;
    private LinearLayout emptyStateLayout; // The empty image container
    private List<CartItem> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // 1. Initialize Views
        cartRecycler = findViewById(R.id.cartRecycler);
        tvTotal = findViewById(R.id.tvTotal);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        Button btnCheckout = findViewById(R.id.btnCheckout);
        ImageButton btnBack = findViewById(R.id.btnBack);
        ImageButton btnClear = findViewById(R.id.btnClearCart); // The Trash Button

        // 2. Setup Back Button
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        // 3. Setup RecyclerView
        cartRecycler.setLayoutManager(new LinearLayoutManager(this));

        // Get LIVE list from Manager
        cartItems = CartManager.getInstance().getItems();

        adapter = new CartAdapter(cartItems, new CartAdapter.OnCartChangeListener() {
            @Override
            public void onItemChanged() {
                updateUI(); // Recalculate total & check if empty
            }
        });
        cartRecycler.setAdapter(adapter);

        // 4. Checkout Logic
        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Cart is empty!", Toast.LENGTH_SHORT).show();
            } else {
                startActivity(new Intent(CartActivity.this, CheckoutActivity.class));
            }
        });

        // 5. 🔥 CLEAR CART LOGIC (Trash Button)
        btnClear.setOnClickListener(v -> {
            if (cartItems.isEmpty()) return;

            new AlertDialog.Builder(this)
                    .setTitle("Clear Cart?")
                    .setMessage("Are you sure you want to remove all items?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        CartManager.getInstance().clear();
                        adapter.notifyDataSetChanged();
                        updateUI();
                        Toast.makeText(this, "Cart cleared", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        // Initial UI Update
        updateUI();
    }

    // 🔥 VITAL: Refreshes data when coming back from Edit Screen
    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) {
            // Force the adapter to re-read the list
            adapter.notifyDataSetChanged();
            updateUI();
        }
    }

    private void updateUI() {
        // 1. Update Total Price
        double total = CartManager.getInstance().getTotalPrice();
        if (tvTotal != null) {
            tvTotal.setText("RM " + String.format("%.2f", total));
        }

        // 2. Toggle Empty State Image
        if (cartItems.isEmpty()) {
            cartRecycler.setVisibility(View.GONE);
            emptyStateLayout.setVisibility(View.VISIBLE);
        } else {
            cartRecycler.setVisibility(View.VISIBLE);
            emptyStateLayout.setVisibility(View.GONE);
        }
    }
}