package com.quicksip.cp2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView cartRecycler;
    private CartAdapter adapter;
    private List<CartItem> cartItems;
    private TextView tvTotal;
    private Button btnCheckout;
    private ImageButton btnClearCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cartRecycler = findViewById(R.id.cartRecycler);
        tvTotal = findViewById(R.id.tvCartTotal);
        btnCheckout = findViewById(R.id.btnCheckout);
        btnClearCart = findViewById(R.id.btnClearCart); // Init Delete Button

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Logic for the trash can icon (Delete whole cart)
        btnClearCart.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Cart is already empty", Toast.LENGTH_SHORT).show();
                return;
            }
            // 1. Setup the Builder
            androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
            builder.setTitle("Delete Cart");
            builder.setMessage("Are you sure you want to delete your cart?");
            // 2. Set the DELETE button (Positive)
            builder.setPositiveButton("DELETE", (dialog, which) -> {
                CartManager.getInstance().clearCart();
                loadCart();
                Toast.makeText(this, "Cart Cleared", Toast.LENGTH_SHORT).show();
            });
            // 3. Set the CANCEL button (Negative)
            builder.setNegativeButton("Cancel", (dialog, which) -> {
                dialog.dismiss();
            });
            // 4. Create and Show the dialog
            androidx.appcompat.app.AlertDialog dialog = builder.create();
            dialog.show();

            // Get the buttons from the dialog
            Button btnDelete = dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE);
            Button btnCancel = dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE);

            // Style DELETE Button (Solid Green with White Text)
            btnDelete.setBackgroundColor(android.graphics.Color.parseColor("#00C853"));
            btnDelete.setTextColor(android.graphics.Color.WHITE);

            // Style CANCEL Button (Transparent with Grey Text)
            btnCancel.setBackgroundColor(Color.WHITE);
            btnCancel.setTextColor(Color.RED);

            // Add Space between the buttons (Margin)
            android.widget.LinearLayout.LayoutParams params = (android.widget.LinearLayout.LayoutParams) btnDelete.getLayoutParams();
            params.leftMargin = 30; // 30px gap
            btnDelete.setLayoutParams(params);
        });

        cartRecycler.setLayoutManager(new LinearLayoutManager(this));
        cartItems = new ArrayList<>();

        // Use the global CartManager items to ensure sync
        cartItems = CartManager.getInstance().getItems();

        adapter = new CartAdapter(cartItems, this::calculateTotal);
        cartRecycler.setAdapter(adapter);

        calculateTotal(); // Initial calc

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(CartActivity.this, CheckoutActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload data when returning from Edit Screen
        adapter.notifyDataSetChanged();
        calculateTotal();
    }

    private void loadCart() {
        // Just notify adapter since we are using CartManager's static list
        adapter.notifyDataSetChanged();
        calculateTotal();
    }

    private void calculateTotal() {
        double total = 0;
        for (CartItem item : cartItems) {
            total += (item.getFinalPrice() * item.getQuantity());
        }
        tvTotal.setText("Total: RM " + String.format("%.2f", total));
    }
}