package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView cartRecycler;
    private CartAdapter adapter;
    private List<CartItem> cartItems;
    private TextView tvTotal;
    private Button btnCheckout;
    private ImageButton btnClearCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cartRecycler = findViewById(R.id.cartRecycler);
        tvTotal = findViewById(R.id.tvCartTotal);
        btnCheckout = findViewById(R.id.btnCheckout);
        btnClearCart = findViewById(R.id.btnClearCart); // ✅ Init Delete Button

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // ✅ Clear Cart Logic
        btnClearCart.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Cart is already empty", Toast.LENGTH_SHORT).show();
                return;
            }

            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Delete Cart")
                    .setMessage("Are you sure you want to delete your cart?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // User clicked Yes -> Clear everything
                        CartManager.getInstance().clearCart();
                        loadCart();
                        Toast.makeText(this, "Cart Cleared", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", (dialog, which) -> {
                        // User clicked No -> Do nothing, just close dialog
                        dialog.dismiss();
                    })
                    .show();
        });

        cartRecycler.setLayoutManager(new LinearLayoutManager(this));
        cartItems = new ArrayList<>();

        // Use the global CartManager items to ensure sync
        cartItems = CartManager.getInstance().getItems();

        adapter = new CartAdapter(cartItems, this::calculateTotal);
        cartRecycler.setAdapter(adapter);

        calculateTotal(); // Initial calc

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(CartActivity.this, CheckoutActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // ✅ Reload data when returning from Edit Screen
        adapter.notifyDataSetChanged();
        calculateTotal();
    }

    private void loadCart() {
        // Just notify adapter since we are using CartManager's static list
        adapter.notifyDataSetChanged();
        calculateTotal();
    }

    private void calculateTotal() {
        double total = 0;
        for (CartItem item : cartItems) {
            total += (item.getFinalPrice() * item.getQuantity());
        }
        tvTotal.setText("Total: RM " + String.format("%.2f", total));
    }
}