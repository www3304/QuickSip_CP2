package com.quicksip.cp2;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class AdminHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter;
    private List<Order> historyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_history);

        // ✅ 1. SETUP BACK BUTTON
        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        recyclerView = findViewById(R.id.historyRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // ✅ 2. SINGLE ADAPTER INITIALIZATION
        // We pass 'true' so buttons are HIDDEN
        adapter = new KitchenOrderAdapter(
                historyList,
                true,
                new KitchenOrderAdapter.OnKitchenActionListener() {
                    @Override
                    public void onStatusChange(int position, String newStatus) {
                        // History is read-only, do nothing
                    }

                    @Override
                    public void onMarkCompleted(int position) {
                        // History is read-only, do nothing
                    }

                    @Override
                    public void onCancelOrder(int position) {
                        // History is read-only, do nothing
                    }
                }
        );

        recyclerView.setAdapter(adapter);

        // 🔥 3. FIRESTORE QUERY (Completed & Cancelled Orders)
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereIn("status", java.util.Arrays.asList("COMPLETED", "CANCELLED")) // Show both types in history
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    historyList.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        try {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setFirestoreId(doc.getId());
                                historyList.add(order);
                            }
                        } catch (Exception ex) {
                            // Skip bad data
                        }
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}