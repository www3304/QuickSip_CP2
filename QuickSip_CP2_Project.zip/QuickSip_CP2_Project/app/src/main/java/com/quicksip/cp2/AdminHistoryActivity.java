package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AdminHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter; // Reusing KitchenAdapter for Admin View
    private List<Order> allHistory = new ArrayList<>();
    private List<Order> displayedHistory = new ArrayList<>();

    private Button btnCompleted, btnCancelled;
    private String currentFilter = "COMPLETED";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_history);

        // 1. Init
        recyclerView = findViewById(R.id.historyRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        btnCompleted = findViewById(R.id.btnTabCompleted);
        btnCancelled = findViewById(R.id.btnTabCancelled);
        // findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // 2. Adapter (isHistory = true, so no buttons shown)
        adapter = new KitchenOrderAdapter(displayedHistory, true, null);
        recyclerView.setAdapter(adapter);

        // 3. Listeners
        btnCompleted.setOnClickListener(v -> setFilter("COMPLETED"));
        btnCancelled.setOnClickListener(v -> setFilter("CANCELLED"));

        setFilter("COMPLETED");

        // 4. Fetch Data (Only Completed & Cancelled)
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereIn("status", Arrays.asList("COMPLETED", "CANCELLED"))
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(snapshots -> {
                    allHistory.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) allHistory.add(order);
                    }
                    applyFilter();
                });

        // 5. Navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_history);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) {
                startActivity(new Intent(this, AdminDashboardActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (id == R.id.nav_kitchen) {
                startActivity(new Intent(this, KitchenOrdersActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return id == R.id.nav_history;
        });
    }

    private void setFilter(String status) {
        currentFilter = status;
        btnCompleted.setSelected(status.equals("COMPLETED"));
        btnCancelled.setSelected(status.equals("CANCELLED"));
        applyFilter();
    }

    private void applyFilter() {
        displayedHistory.clear();
        for (Order order : allHistory) {
            String s = order.getStatus() != null ? order.getStatus().toUpperCase() : "";
            if (s.equals(currentFilter)) {
                displayedHistory.add(order);
            }
        }
        adapter.notifyDataSetChanged();
    }
}