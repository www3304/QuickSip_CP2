package com.quicksip.cp2;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class AdminHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter;
    private List<Order> historyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_history);

        recyclerView = findViewById(R.id.historyRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 🔥 Reuse the adapter but DISABLE the buttons logic
        adapter = new KitchenOrderAdapter(historyList, new KitchenOrderAdapter.OnKitchenActionListener() {
            @Override
            public void onStatusChange(int position, String newStatus) {
                Toast.makeText(AdminHistoryActivity.this, "Cannot change history!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onMarkCompleted(int position) {
                // Do nothing
            }
        });

        recyclerView.setAdapter(adapter);

        // 🔥 QUERY: Only show COMPLETED orders
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereEqualTo("status", "COMPLETED")
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    historyList.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            order.setFirestoreId(doc.getId());
                            historyList.add(order);
                        }
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}