package com.quicksip.cp2;

public class DrinkItem {
    private String name;
    private double price;
    private int imageResId;
    private String category; // ✅ New Field

    public DrinkItem(String name, double price, int imageResId, String category) {
        this.name = name;
        this.price = price;
        this.imageResId = imageResId;
        this.category = category;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getImageResId() { return imageResId; }
    public String getCategory() { return category; } // ✅ New Getter
}