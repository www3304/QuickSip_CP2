package com.quicksip.cp2;

import java.util.Arrays;
import java.util.List;

public class DrinkItem {
    private String name;
    private double price;
    private int imageResId;
    private List<String> categories;

    public DrinkItem(String name, double price, int imageResId, String... categories) {
        this.name = name;
        this.price = price;
        this.imageResId = imageResId;
        this.categories = Arrays.asList(categories);
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getImageResId() { return imageResId; }

    public boolean hasCategory(String category) {
        return categories.contains(category);
    }

    // ✅ NEW: Add this Getter so we can pass categories to the next screen
    public List<String> getCategories() {
        return categories;
    }
}