package com.quicksip.cp2;

import java.util.Arrays;
import java.util.List;

public class DrinkItem {
    private String name;
    private String description;
    private double price;
    private int imageResId;
    private List<String> categories;

    // Updated Constructor to include description
    public DrinkItem(String name, String description, double price, int imageResId, String... categories) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResId = imageResId;
        this.categories = Arrays.asList(categories);
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getImageResId() { return imageResId; }
    public List<String> getCategories() { return categories; }

    public boolean hasCategory(String category) {
        return categories.contains(category);
    }
}