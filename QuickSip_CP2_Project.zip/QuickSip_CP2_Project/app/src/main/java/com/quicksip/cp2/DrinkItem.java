package com.quicksip.cp2;

import java.util.Arrays;
import java.util.List;

public class DrinkItem {
    private String name;
    private double price;
    private int imageResId;
    private List<String> categories; // ✅ Changed to List

    // Constructor now accepts multiple categories (e.g., "Coffee", "Latte")
    public DrinkItem(String name, double price, int imageResId, String... categories) {
        this.name = name;
        this.price = price;
        this.imageResId = imageResId;
        this.categories = Arrays.asList(categories);
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getImageResId() { return imageResId; }

    // ✅ Check if this drink belongs to a specific category
    public boolean hasCategory(String category) {
        return categories.contains(category);
    }
}