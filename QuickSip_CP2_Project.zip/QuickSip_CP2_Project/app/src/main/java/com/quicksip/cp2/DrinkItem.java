package com.quicksip.cp2;

public class DrinkItem {
    private String name;
    private double price;
    private int imageResId; // for now using drawable resources

    public DrinkItem(String name, double price, int imageResId) {
        this.name = name;
        this.price = price;
        this.imageResId = imageResId;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getImageResId() { return imageResId; }
}
