package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class KitchenOrderAdapter
        extends RecyclerView.Adapter<KitchenOrderAdapter.KitchenViewHolder> {

    public interface OnKitchenActionListener {
        void onStatusChange(int position, String newStatus);
        void onMarkCompleted(int position);
    }

    private final List<Order> orders;
    private final OnKitchenActionListener listener;

    public KitchenOrderAdapter(List<Order> orders,
                               OnKitchenActionListener listener) {
        this.orders = orders;
        this.listener = listener;
    }

    @NonNull
    @Override
    public KitchenViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_kitchen_order, parent, false);

        return new KitchenViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull KitchenViewHolder holder, int position) {

        Order order = orders.get(position);

        holder.tvTitle.setText("Order #" + order.getOrderId());
        holder.tvDetails.setText(buildSummary(order));
        holder.tvStatus.setText("Status: " + order.getStatus());

        // 🎨 NEW: Change Color based on Status
        int color;
        switch (order.getStatus()) {
            case "PREPARING":
                color = android.graphics.Color.parseColor("#FFA726"); // Orange
                break;
            case "READY":
                color = android.graphics.Color.parseColor("#66BB6A"); // Green
                break;
            case "COMPLETED":
                color = android.graphics.Color.GRAY;
                break;
            default: // "NEW"
                color = android.graphics.Color.BLUE;
                break;
        }
        holder.tvStatus.setTextColor(color);

        // Reset buttons
        holder.btnNew.setVisibility(View.GONE);
        holder.btnInProgress.setVisibility(View.GONE);
        holder.btnReady.setVisibility(View.GONE);
        holder.btnDone.setVisibility(View.GONE);

        switch (order.getStatus()) {
            case "NEW":
                holder.btnInProgress.setVisibility(View.VISIBLE);
                break;

            case "PREPARING":
                holder.btnReady.setVisibility(View.VISIBLE);
                break;

            case "READY":
                holder.btnDone.setVisibility(View.VISIBLE);
                break;
        }

        holder.btnInProgress.setOnClickListener(v ->
                listener.onStatusChange(position, "PREPARING")
        );

        holder.btnReady.setOnClickListener(v ->
                listener.onStatusChange(position, "READY")
        );

        holder.btnDone.setOnClickListener(v ->
                listener.onMarkCompleted(position)
        );
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    // UI-only summary
    private String buildSummary(Order order) {
        StringBuilder sb = new StringBuilder();

        for (CartItem item : order.getItems()) {
            sb.append("• ")
                    .append(item.getDrinkName())
                    .append(" x")
                    .append(item.getQuantity())
                    .append("\n");
        }

        sb.append("\nTotal: RM ")
                .append(String.format("%.2f", order.getTotalPrice()));

        return sb.toString();
    }

    static class KitchenViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle, tvDetails, tvStatus;
        Button btnNew, btnInProgress, btnReady, btnDone;

        KitchenViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDetails = itemView.findViewById(R.id.tvDetails);
            tvStatus = itemView.findViewById(R.id.tvStatus);

            btnNew = itemView.findViewById(R.id.btnNew);
            btnInProgress = itemView.findViewById(R.id.btnInProgress);
            btnReady = itemView.findViewById(R.id.btnReady);
            btnDone = itemView.findViewById(R.id.btnDone);
        }
    }
}
