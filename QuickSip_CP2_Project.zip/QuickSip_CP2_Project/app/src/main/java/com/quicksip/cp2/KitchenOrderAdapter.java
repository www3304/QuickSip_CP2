package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class KitchenOrderAdapter extends RecyclerView.Adapter<KitchenOrderAdapter.KitchenViewHolder> {

    private final List<Order> orders;
    private final OnKitchenActionListener listener;
    private final boolean isHistory;

    public interface OnKitchenActionListener {
        void onStatusChange(int position, String newStatus);
        void onMarkCompleted(int position);
        void onCancelOrder(int position);
    }

    public KitchenOrderAdapter(List<Order> orders, boolean isHistory, OnKitchenActionListener listener) {
        this.orders = orders;
        this.isHistory = isHistory;
        this.listener = listener;
    }

    @NonNull
    @Override
    public KitchenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kitchen_order, parent, false);
        return new KitchenViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull KitchenViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.tvOrderId.setText("Order #" + order.getOrderId());
        holder.tvTableNo.setText("User: " + order.getUserId());

        String status = order.getStatus() != null ? order.getStatus().toUpperCase() : "NEW";
        holder.tvStatusLabel.setText(status);

        int color = Color.BLUE;
        if (status.equals("PREPARING")) color = Color.parseColor("#FFA726");
        if (status.equals("READY")) color = Color.parseColor("#66BB6A");
        if (status.equals("COMPLETED")) color = Color.GRAY;
        if (status.equals("CANCELLED")) color = Color.RED;
        holder.tvStatusLabel.setTextColor(color);

        // --- ITEMS ROW ---
        holder.itemsContainer.removeAllViews();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                View row = LayoutInflater.from(holder.itemView.getContext())
                        .inflate(R.layout.item_order_row, holder.itemsContainer, false);

                TextView tvName = row.findViewById(R.id.tvRowName);
                TextView tvDetails = row.findViewById(R.id.tvRowDetails);
                TextView tvPrice = row.findViewById(R.id.tvRowPrice);

                tvName.setText(item.getQuantity() + "x " + item.getDrinkName());

                StringBuilder details = new StringBuilder();
                details.append(item.getSize()).append(", ")
                        .append(item.getSugar()).append(", ")
                        .append(item.getIce());

                if (item.getToppings() != null && !item.getToppings().isEmpty()) {
                    details.append("\n+ ").append(item.getToppings());
                }
                tvDetails.setText(details.toString());

                // Price Self-Healing Logic
                double unitPrice = item.getFinalPrice();
                boolean hasToppings = item.getToppings() != null && !item.getToppings().isEmpty();
                boolean isLarge = "Large".equalsIgnoreCase(item.getSize());

                if (unitPrice == 0 || (unitPrice == item.getBasePrice() && (hasToppings || isLarge))) {
                    unitPrice = item.getBasePrice() > 0 ? item.getBasePrice() : 0;
                    if (isLarge) unitPrice += 2.00;
                    if (hasToppings) {
                        String t = item.getToppings();
                        if (t.contains("Pearl")) unitPrice += 1.0;
                        if (t.contains("Pudding")) unitPrice += 1.0;
                        if (t.contains("Red Bean")) unitPrice += 1.0;
                        if (t.contains("Aloe Vera")) unitPrice += 1.0;
                        if (t.contains("Chia Seeds")) unitPrice += 1.0;
                        if (t.contains("Jelly")) unitPrice += 1.0;
                        if (t.contains("Soy Milk")) unitPrice += 1.0;
                        if (t.contains("Oat Milk")) unitPrice += 2.0;
                        if (t.contains("Extra Shot")) unitPrice += 2.0;
                    }
                }

                double lineTotal = unitPrice * item.getQuantity();
                tvPrice.setText("RM " + String.format("%.2f", lineTotal));

                holder.itemsContainer.addView(row);
            }
        }

        holder.tvKitchenTotal.setText("Total: RM " + String.format("%.2f", order.getTotalPrice()));

        // --- BUTTON LOGIC UPDATE ---
        if (isHistory) {
            holder.actionLayout.setVisibility(View.GONE);
        } else {
            holder.actionLayout.setVisibility(View.VISIBLE);

            // 1. Reset ALL buttons to GONE first
            holder.btnInProgress.setVisibility(View.GONE);
            holder.btnReady.setVisibility(View.GONE);
            holder.btnDone.setVisibility(View.GONE);
            holder.btnCancel.setVisibility(View.GONE); // Default hidden

            switch (status) {
                case "NEW":
                    holder.btnInProgress.setVisibility(View.VISIBLE);
                    holder.btnCancel.setVisibility(View.VISIBLE); // ✅ Show Cancel ONLY for New
                    break;
                case "PREPARING":
                    holder.btnReady.setVisibility(View.VISIBLE);
                    // Cancel remains GONE
                    break;
                case "READY":
                    holder.btnDone.setVisibility(View.VISIBLE);
                    // Cancel remains GONE
                    break;
                default:
                    if (!status.equals("COMPLETED") && !status.equals("CANCELLED")) {
                        holder.btnInProgress.setVisibility(View.VISIBLE);
                        holder.btnCancel.setVisibility(View.VISIBLE);
                    } else {
                        holder.actionLayout.setVisibility(View.GONE);
                    }
                    break;
            }
        }

        holder.btnInProgress.setOnClickListener(v -> listener.onStatusChange(position, "PREPARING"));
        holder.btnReady.setOnClickListener(v -> listener.onStatusChange(position, "READY"));
        holder.btnDone.setOnClickListener(v -> listener.onMarkCompleted(position));
        holder.btnCancel.setOnClickListener(v -> listener.onCancelOrder(position));
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class KitchenViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvTableNo, tvStatusLabel, tvKitchenTotal;
        LinearLayout itemsContainer, actionLayout;
        Button btnInProgress, btnReady, btnDone, btnCancel;

        KitchenViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvTableNo = itemView.findViewById(R.id.tvTableNo);
            itemsContainer = itemView.findViewById(R.id.itemsContainer);
            tvStatusLabel = itemView.findViewById(R.id.tvStatusLabel);
            tvKitchenTotal = itemView.findViewById(R.id.tvKitchenTotal);
            actionLayout = itemView.findViewById(R.id.actionLayout);
            btnInProgress = itemView.findViewById(R.id.btnInProgress);
            btnReady = itemView.findViewById(R.id.btnReady);
            btnDone = itemView.findViewById(R.id.btnDone);
            btnCancel = itemView.findViewById(R.id.btnCancel);
        }
    }
}