package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class KitchenOrderAdapter extends RecyclerView.Adapter<KitchenOrderAdapter.KitchenViewHolder> {

    private final List<Order> orders;
    private final OnKitchenActionListener listener;
    private final boolean isHistory; // ✅ Control flag

    public interface OnKitchenActionListener {
        void onStatusChange(int position, String newStatus);
        void onMarkCompleted(int position);
        void onCancelOrder(int position);
    }

    // Constructor
    public KitchenOrderAdapter(List<Order> orders, boolean isHistory, OnKitchenActionListener listener) {
        this.orders = orders;
        this.isHistory = isHistory; // ✅ Store the flag
        this.listener = listener;
    }

    @NonNull
    @Override
    public KitchenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kitchen_order, parent, false);
        return new KitchenViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull KitchenViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.tvOrderId.setText("Order #" + order.getOrderId());
        holder.tvTableNo.setText("User: " + order.getUserId());
        holder.tvStatusLabel.setText("Status: " + order.getStatus());

        // Color Logic
        int color = Color.BLUE;
        String status = order.getStatus() != null ? order.getStatus() : "NEW";
        if (status.equals("PREPARING")) color = Color.parseColor("#FFA726");
        if (status.equals("READY")) color = Color.parseColor("#66BB6A");
        if (status.equals("COMPLETED")) color = Color.GRAY;
        if (status.equals("CANCELLED")) color = Color.RED;
        holder.tvStatusLabel.setTextColor(color);

        // Build Summary
        StringBuilder itemsText = new StringBuilder();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                itemsText.append("• ").append(item.getQuantity()).append("x ")
                        .append(item.getDrinkName()).append(" (").append(item.getSize()).append(")\n");
            }
        }
        holder.tvItems.setText(itemsText.toString().trim());

        // ----------------------------------------------------
        // ✅ BUTTON VISIBILITY LOGIC
        // ----------------------------------------------------

        if (isHistory) {
            // HISTORY MODE: Hide EVERYTHING
            holder.actionLayout.setVisibility(View.GONE);
        } else {
            // KITCHEN MODE: Show buttons based on Status
            holder.actionLayout.setVisibility(View.VISIBLE);

            // Reset all first
            holder.btnInProgress.setVisibility(View.GONE);
            holder.btnReady.setVisibility(View.GONE);
            holder.btnDone.setVisibility(View.GONE);
            holder.btnCancel.setVisibility(View.VISIBLE); // Cancel always allowed for active

            switch (status) {
                case "NEW":
                    holder.btnInProgress.setVisibility(View.VISIBLE); // Show "Accept"
                    break;
                case "PREPARING":
                    holder.btnReady.setVisibility(View.VISIBLE); // Show "Ready"
                    break;
                case "READY":
                    holder.btnDone.setVisibility(View.VISIBLE); // Show "Complete"
                    break;
                default:
                    // If Cancelled or Completed, hide actions
                    holder.actionLayout.setVisibility(View.GONE);
                    break;
            }
        }

        // ----------------------------------------------------
        // ✅ CLICK LISTENERS
        // ----------------------------------------------------
        holder.btnInProgress.setOnClickListener(v -> listener.onStatusChange(position, "PREPARING"));
        holder.btnReady.setOnClickListener(v -> listener.onStatusChange(position, "READY"));
        holder.btnDone.setOnClickListener(v -> listener.onMarkCompleted(position));
        holder.btnCancel.setOnClickListener(v -> listener.onCancelOrder(position));
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class KitchenViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvTableNo, tvItems, tvStatusLabel;
        LinearLayout actionLayout;
        Button btnInProgress, btnReady, btnDone, btnCancel;

        KitchenViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvTableNo = itemView.findViewById(R.id.tvTableNo);
            tvItems = itemView.findViewById(R.id.tvItems);
            tvStatusLabel = itemView.findViewById(R.id.tvStatusLabel);
            actionLayout = itemView.findViewById(R.id.actionLayout);

            btnInProgress = itemView.findViewById(R.id.btnInProgress);
            btnReady = itemView.findViewById(R.id.btnReady);
            btnDone = itemView.findViewById(R.id.btnDone);
            btnCancel = itemView.findViewById(R.id.btnCancel);
        }
    }
}