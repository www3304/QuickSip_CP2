package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.util.Arrays;
import java.util.List;

public class DrinkCustomizeActivity extends AppCompatActivity {

    private ImageView imgDrink;
    private TextView tvName, tvPrice, tvQuantity, tvToppingsTitle;
    private ImageButton btnMinus, btnPlus;
    private Button btnAddToCart;
    private RadioGroup rgSize, rgSugar, rgIce;

    private CheckBox cbOption1, cbOption2, cbOption3;
    private LinearLayout layoutToppings;

    private double basePrice; // holds the Original Price
    private int quantity = 1;

    // Config for dynamic options
    private double priceOpt1 = 0, priceOpt2 = 0, priceOpt3 = 0;
    private String nameOpt1 = "", nameOpt2 = "", nameOpt3 = "";
    private String[] currentCategories;

    private boolean isEditMode = false;
    private int editIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_customize);

        // 1. Initialize Views
        imgDrink = findViewById(R.id.imgCustomizeDrink);
        tvName = findViewById(R.id.tvCustomizeName);
        tvPrice = findViewById(R.id.tvCustomizePrice);
        tvQuantity = findViewById(R.id.tvQuantity);
        tvToppingsTitle = findViewById(R.id.tvToppingsTitle);
        layoutToppings = findViewById(R.id.layoutToppings);

        btnMinus = findViewById(R.id.btnMinus);
        btnPlus = findViewById(R.id.btnPlus);
        btnAddToCart = findViewById(R.id.btnAddToCart);

        rgSize = findViewById(R.id.rgSize);
        rgSugar = findViewById(R.id.rgSugar);
        rgIce = findViewById(R.id.rgIce);

        cbOption1 = findViewById(R.id.cbPearl);
        cbOption2 = findViewById(R.id.cbPudding);
        cbOption3 = findViewById(R.id.cbJelly);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // 2. Get Data from Intent
        Intent intent = getIntent();
        String name = intent.getStringExtra("drinkName");
        basePrice = intent.getDoubleExtra("drinkPrice", 0.0); // ✅ Always load Original Price
        int imageResId = intent.getIntExtra("drinkImage", 0);
        currentCategories = intent.getStringArrayExtra("drinkCategories");

        // 3. Setup UI
        tvName.setText(name);
        if (imageResId != 0) {
            Glide.with(this).load(imageResId).into(imgDrink);
        }

        setupDynamicOptions(currentCategories);

        // 4. CHECK FOR EDIT MODE
        if (intent.hasExtra("editIndex")) {
            isEditMode = true;
            editIndex = intent.getIntExtra("editIndex", -1);
            quantity = intent.getIntExtra("editQty", 1);
            btnAddToCart.setText("Update Cart");

            tvQuantity.setText(String.valueOf(quantity));

            // Set Size
            String size = intent.getStringExtra("editSize");
            if (size != null && size.contains("Large")) {
                rgSize.check(R.id.sizeLarge);
            } else {
                rgSize.check(R.id.sizeRegular);
            }

            setRadioSelection(rgSugar, intent.getStringExtra("editSugar"));
            setRadioSelection(rgIce, intent.getStringExtra("editIce"));

            // Set Toppings
            String toppings = intent.getStringExtra("editToppings");
            if (toppings != null) {
                if (!nameOpt1.isEmpty() && toppings.contains(nameOpt1)) cbOption1.setChecked(true);
                if (!nameOpt2.isEmpty() && toppings.contains(nameOpt2)) cbOption2.setChecked(true);
                if (!nameOpt3.isEmpty() && toppings.contains(nameOpt3)) cbOption3.setChecked(true);
            }
        }

        updateTotalPrice();

        // 5. Listeners
        btnPlus.setOnClickListener(v -> { quantity++; updateQuantityUI(); });
        btnMinus.setOnClickListener(v -> { if(quantity > 1) quantity--; updateQuantityUI(); });

        View.OnClickListener updatePriceListener = v -> updateTotalPrice();
        rgSize.setOnCheckedChangeListener((g, i) -> updateTotalPrice());
        cbOption1.setOnClickListener(updatePriceListener);
        cbOption2.setOnClickListener(updatePriceListener);
        cbOption3.setOnClickListener(updatePriceListener);

        btnAddToCart.setOnClickListener(v -> addToCart());
    }

    private void setupDynamicOptions(String[] categories) {
        if (categories == null) return;
        List<String> catList = Arrays.asList(categories);

        if (catList.contains("Bottled")) {
            layoutToppings.setVisibility(View.GONE);
            rgSize.setVisibility(View.GONE);
            rgSugar.setVisibility(View.GONE);
            rgIce.setVisibility(View.GONE);
            return;
        }

        layoutToppings.setVisibility(View.VISIBLE);

        if (catList.contains("Coffee") || catList.contains("Latte")) {
            tvToppingsTitle.setText("Customize Milk / Shot");
            configureOption(cbOption1, "Soy Milk", 1.00);
            configureOption(cbOption2, "Oat Milk", 2.00);
            configureOption(cbOption3, "Extra Shot", 2.00);
            priceOpt1 = 1.0; priceOpt2 = 2.0; priceOpt3 = 2.0;
            nameOpt1 = "Soy Milk"; nameOpt2 = "Oat Milk"; nameOpt3 = "Extra Shot";
        } else if (catList.contains("Refresher")) {
            tvToppingsTitle.setText("Add-ons");
            configureOption(cbOption1, "Aloe Vera", 1.00);
            configureOption(cbOption2, "Chia Seeds", 1.00);
            configureOption(cbOption3, "Jelly", 1.00);
            priceOpt1 = 1.0; priceOpt2 = 1.0; priceOpt3 = 1.0;
            nameOpt1 = "Aloe Vera"; nameOpt2 = "Chia Seeds"; nameOpt3 = "Jelly";
        } else {
            tvToppingsTitle.setText("Toppings");
            configureOption(cbOption1, "Pearls", 1.00);
            configureOption(cbOption2, "Pudding", 1.00);
            configureOption(cbOption3, "Red Bean", 1.00);
            priceOpt1 = 1.0; priceOpt2 = 1.0; priceOpt3 = 1.0;
            nameOpt1 = "Pearls"; nameOpt2 = "Pudding"; nameOpt3 = "Red Bean";
        }
    }

    private void configureOption(CheckBox cb, String text, double price) {
        cb.setText(text + " (+RM" + String.format("%.0f", price) + ")");
        cb.setChecked(false);
    }

    private void updateQuantityUI() {
        tvQuantity.setText(String.valueOf(quantity));
        updateTotalPrice();
    }

    private void updateTotalPrice() {
        // ALWAYS START FROM BASE PRICE
        double total = basePrice;

        int selectedSizeId = rgSize.getCheckedRadioButtonId();
        if (selectedSizeId != -1) {
            RadioButton rb = findViewById(selectedSizeId);
            if (rb != null && rb.getText().toString().contains("Large")) total += 2.00;
        }

        if (cbOption1.isChecked()) total += priceOpt1;
        if (cbOption2.isChecked()) total += priceOpt2;
        if (cbOption3.isChecked()) total += priceOpt3;

        total = total * quantity;
        tvPrice.setText("RM " + String.format("%.2f", total));
    }

    private void setRadioSelection(RadioGroup group, String text) {
        if (text == null) return;
        for (int i=0; i<group.getChildCount(); i++) {
            RadioButton rb = (RadioButton) group.getChildAt(i);
            if (rb.getText().toString().contains(text)) {
                rb.setChecked(true);
                return;
            }
        }
    }

    private void addToCart() {
        RadioButton rbSize = findViewById(rgSize.getCheckedRadioButtonId());
        RadioButton rbSugar = findViewById(rgSugar.getCheckedRadioButtonId());
        RadioButton rbIce = findViewById(rgIce.getCheckedRadioButtonId());

        String size = (rbSize != null) ? rbSize.getText().toString().split(" ")[0] : "Regular";
        String sugar = (rbSugar != null) ? rbSugar.getText().toString() : "Normal";
        String ice = (rbIce != null) ? rbIce.getText().toString() : "Normal";

        StringBuilder toppings = new StringBuilder();
        if (cbOption1.isChecked()) toppings.append(nameOpt1).append(", ");
        if (cbOption2.isChecked()) toppings.append(nameOpt2).append(", ");
        if (cbOption3.isChecked()) toppings.append(nameOpt3).append(", ");

        String toppingsStr = toppings.length() > 0 ? toppings.substring(0, toppings.length() - 2) : "";

        // RECALCULATE FRESH PRICE
        double unitPrice = basePrice;
        if (size.equals("Large")) unitPrice += 2.00;
        if (cbOption1.isChecked()) unitPrice += priceOpt1;
        if (cbOption2.isChecked()) unitPrice += priceOpt2;
        if (cbOption3.isChecked()) unitPrice += priceOpt3;

        List<String> catList = (currentCategories != null) ? Arrays.asList(currentCategories) : null;

        // SAVE BASE PRICE SEPARATELY (3rd argument)
        CartItem cartItem = new CartItem(
                tvName.getText().toString(),
                unitPrice, // Final Price
                basePrice, // Original Price
                quantity,
                size,
                sugar,
                ice,
                toppingsStr,
                getIntent().getIntExtra("drinkImage", 0),
                catList
        );

        if (isEditMode && editIndex != -1) {
            try {
                CartManager.getInstance().getItems().set(editIndex, cartItem);
                Toast.makeText(this, "Cart Updated!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                CartManager.getInstance().addItem(cartItem);
            }
        } else {
            CartManager.getInstance().addItem(cartItem);
            Toast.makeText(this, "Added to Cart!", Toast.LENGTH_SHORT).show();
        }

        finish();
    }
}