package com.quicksip.cp2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

public class DrinkCustomizeActivity extends AppCompatActivity {

    private TextView tvDrinkTitle;
    private RadioGroup rgSize, rgIce, rgSugar;
    private CheckBox toppingPearl, toppingPudding, toppingJelly;
    private Button btnAddToCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_drink_customize);

        tvDrinkTitle = findViewById(R.id.tvDrinkTitle);
        rgSize = findViewById(R.id.rgSize);
        rgIce = findViewById(R.id.rgIce);
        rgSugar = findViewById(R.id.rgSugar);
        toppingPearl = findViewById(R.id.toppingPearl);
        toppingPudding = findViewById(R.id.toppingPudding);
        toppingJelly = findViewById(R.id.toppingJelly);
        btnAddToCart = findViewById(R.id.btnAddToCart);

        // Setup Back Button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Get base drink info from intent
        String drinkName = getIntent().getStringExtra("drinkName");
        double basePrice = getIntent().getDoubleExtra("drinkPrice", 0);
        int imageRes = getIntent().getIntExtra("drinkImage", 0);

        tvDrinkTitle.setText(drinkName);

        btnAddToCart.setOnClickListener(v -> {
            // Defaults
            String size = "Regular";
            String ice = "50%";
            String sugar = "50%";

            // Get Selected Radio Button Values
            int sizeId = rgSize.getCheckedRadioButtonId();
            if (sizeId != -1) size = ((RadioButton) findViewById(sizeId)).getText().toString();

            int iceId = rgIce.getCheckedRadioButtonId();
            if (iceId != -1) ice = ((RadioButton) findViewById(iceId)).getText().toString();

            int sugarId = rgSugar.getCheckedRadioButtonId();
            if (sugarId != -1) sugar = ((RadioButton) findViewById(sugarId)).getText().toString();

            // Calculate Toppings
            StringBuilder toppingResult = new StringBuilder();
            double toppingPrice = 0;

            if (toppingPearl.isChecked()) { toppingResult.append("Pearl "); toppingPrice += 1.50; }
            if (toppingPudding.isChecked()) { toppingResult.append("Pudding "); toppingPrice += 1.50; }
            if (toppingJelly.isChecked()) { toppingResult.append("Jelly "); toppingPrice += 1.00; }

            String toppingsFinal = toppingResult.toString().trim();

            // Calculate Price
            double finalPrice = basePrice;
            if (size.contains("Large")) finalPrice += 1.00;
            finalPrice += toppingPrice;

            // ✅ FIXED: Passing '1' as quantity in the 3rd position
            CartItem item = new CartItem(
                    drinkName,      // 1. Name
                    basePrice,      // 2. Base Price
                    1,              // 3. Quantity (The missing INT!)
                    size,           // 4. Size
                    ice,            // 5. Ice
                    sugar,          // 6. Sugar
                    toppingsFinal,  // 7. Toppings
                    finalPrice,     // 8. Final Price
                    imageRes        // 9. Image ID
            );

            CartManager.getInstance().addOrMerge(item);

            Toast.makeText(this, "Added to cart!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}