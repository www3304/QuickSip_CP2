package com.quicksip.cp2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

public class DrinkCustomizeActivity extends AppCompatActivity {

    private TextView tvDrinkTitle;
    private RadioGroup rgSize, rgIce, rgSugar;
    private CheckBox toppingPearl, toppingPudding, toppingJelly;
    private Button btnAddToCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ STOP drawing under status bar
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);

        setContentView(R.layout.activity_drink_customize);

        tvDrinkTitle = findViewById(R.id.tvDrinkTitle);
        rgSize = findViewById(R.id.rgSize);
        rgIce = findViewById(R.id.rgIce);
        rgSugar = findViewById(R.id.rgSugar);
        toppingPearl = findViewById(R.id.toppingPearl);
        toppingPudding = findViewById(R.id.toppingPudding);
        toppingJelly = findViewById(R.id.toppingJelly);
        btnAddToCart = findViewById(R.id.btnAddToCart);

        // Get base drink info from intent
        String drinkName = getIntent().getStringExtra("drinkName");
        double basePrice = getIntent().getDoubleExtra("drinkPrice", 0);
        int imageRes = getIntent().getIntExtra("drinkImage", 0);

        tvDrinkTitle.setText(drinkName);

        btnAddToCart.setOnClickListener(v -> {

            // ---------- SAFE DEFAULTS ----------
            String size = "Regular";
            String ice = "50%";
            String sugar = "50%";

            // ---------- SIZE ----------
            int sizeId = rgSize.getCheckedRadioButtonId();
            if (sizeId != -1) {
                RadioButton rb = findViewById(sizeId);
                if (rb != null) size = rb.getText().toString();
            }

            // ---------- ICE ----------
            int iceId = rgIce.getCheckedRadioButtonId();
            if (iceId != -1) {
                RadioButton rb = findViewById(iceId);
                if (rb != null) ice = rb.getText().toString();
            }

            // ---------- SUGAR ----------
            int sugarId = rgSugar.getCheckedRadioButtonId();
            if (sugarId != -1) {
                RadioButton rb = findViewById(sugarId);
                if (rb != null) sugar = rb.getText().toString();
            }

            // ---------- TOPPINGS ----------
            StringBuilder toppingResult = new StringBuilder();
            double toppingPrice = 0;

            if (toppingPearl.isChecked()) {
                toppingResult.append("Pearl ");
                toppingPrice += 1.50;
            }
            if (toppingPudding.isChecked()) {
                toppingResult.append("Pudding ");
                toppingPrice += 1.50;
            }
            if (toppingJelly.isChecked()) {
                toppingResult.append("Jelly ");
                toppingPrice += 1.00;
            }

            String toppingsFinal = toppingResult.toString().trim();

            // ---------- FINAL PRICE ----------
            double finalPrice = basePrice;
            if (size.contains("Large")) finalPrice += 1.00;
            finalPrice += toppingPrice;

            // ---------- CREATE CART ITEM ----------
            CartItem item = new CartItem(
                    drinkName,
                    basePrice,
                    size,
                    ice,
                    sugar,
                    toppingsFinal,
                    finalPrice,
                    imageRes
            );

            CartManager.getInstance().addOrMerge(item);

            Toast.makeText(this, "Added to cart!", Toast.LENGTH_SHORT).show();
            finish();
        });

        if (drinkName == null) {
            Toast.makeText(this, "Drink data error", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
    }
}
