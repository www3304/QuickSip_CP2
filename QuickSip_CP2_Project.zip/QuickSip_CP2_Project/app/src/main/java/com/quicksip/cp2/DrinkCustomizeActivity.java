package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DrinkCustomizeActivity extends AppCompatActivity {

    private TextView tvDrinkTitle;
    private RadioGroup rgSize, rgIce, rgSugar;
    private CheckBox cbPearl, cbPudding, cbJelly;
    private Button btnAddToCart;
    private ImageButton btnBack;

    private String drinkName;
    private double basePrice;
    private int quantity = 1;

    // Edit Mode Variables
    private boolean isEditMode = false;
    private int editIndex = -1; // 🔥 Store the index of the item being edited

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_customize);

        // 1. Init Views
        tvDrinkTitle = findViewById(R.id.tvDrinkTitle);
        btnBack = findViewById(R.id.btnBack);
        rgSize = findViewById(R.id.rgSize);
        rgIce = findViewById(R.id.rgIce);
        rgSugar = findViewById(R.id.rgSugar);
        cbPearl = findViewById(R.id.toppingPearl);
        cbPudding = findViewById(R.id.toppingPudding);
        cbJelly = findViewById(R.id.toppingJelly);
        btnAddToCart = findViewById(R.id.btnAddToCart);

        btnBack.setOnClickListener(v -> finish());

        // 2. Load Intent Data
        Intent intent = getIntent();
        drinkName = intent.getStringExtra("drinkName");
        basePrice = intent.getDoubleExtra("drinkPrice", 0.0);
        tvDrinkTitle.setText(drinkName != null ? drinkName : "Customize Drink");

        // 3. CHECK FOR EDIT MODE
        if (intent.hasExtra("editQty")) {
            isEditMode = true;
            quantity = intent.getIntExtra("editQty", 1);
            editIndex = intent.getIntExtra("editIndex", -1); // 🔥 Get the index

            btnAddToCart.setText("Update Order");

            // Select Size
            String size = intent.getStringExtra("editSize");
            if ("Large".equals(size)) rgSize.check(R.id.sizeLarge);
            else rgSize.check(R.id.sizeRegular);

            // Select Ice & Sugar
            setRadioSelection(rgIce, intent.getStringExtra("editIce"));
            setRadioSelection(rgSugar, intent.getStringExtra("editSugar"));

            // Check Toppings
            String toppings = intent.getStringExtra("editToppings");
            if (toppings != null) {
                if (toppings.contains("Pearl")) cbPearl.setChecked(true);
                if (toppings.contains("Pudding")) cbPudding.setChecked(true);
                if (toppings.contains("Jelly")) cbJelly.setChecked(true);
            }
        }

        btnAddToCart.setOnClickListener(v -> addToCart());
    }

    private void setRadioSelection(RadioGroup group, String value) {
        if (value == null) return;
        for (int i = 0; i < group.getChildCount(); i++) {
            RadioButton btn = (RadioButton) group.getChildAt(i);
            if (btn.getText().toString().equalsIgnoreCase(value)) {
                btn.setChecked(true);
                break;
            }
        }
    }

    private void addToCart() {
        // 1. Get Selected Options
        String selectedSize = "Regular";
        if (rgSize.getCheckedRadioButtonId() == R.id.sizeLarge) {
            selectedSize = "Large";
        }

        String selectedIce = getSelectedRadioText(rgIce);
        String selectedSugar = getSelectedRadioText(rgSugar);

        // 2. Get Toppings
        StringBuilder toppingsBuilder = new StringBuilder();
        if (cbPearl.isChecked()) toppingsBuilder.append("Pearl, ");
        if (cbPudding.isChecked()) toppingsBuilder.append("Pudding, ");
        if (cbJelly.isChecked()) toppingsBuilder.append("Jelly, ");

        String toppingStr = toppingsBuilder.toString();
        if (toppingStr.endsWith(", ")) {
            toppingStr = toppingStr.substring(0, toppingStr.length() - 2);
        }

        // 3. Create Item
        CartItem newItem = new CartItem(
                drinkName,
                basePrice,
                selectedSize,
                selectedSugar,
                selectedIce,
                quantity
        );
        newItem.setToppings(toppingStr);

        // 4. 🔥 SAVE OR UPDATE
        if (isEditMode && editIndex != -1) {
            // Update the specific item at editIndex (replaces the old one)
            // This is "in-place" editing, so order stays the same.
            try {
                CartManager.getInstance().getItems().set(editIndex, newItem);
                Toast.makeText(this, "Order Updated!", Toast.LENGTH_SHORT).show();
            } catch (IndexOutOfBoundsException e) {
                // Just in case the index is wrong, add as new
                CartManager.getInstance().addItem(newItem);
            }
        } else {
            // Add new item
            CartManager.getInstance().addItem(newItem);
            Toast.makeText(this, "Added to Cart", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private String getSelectedRadioText(RadioGroup group) {
        int id = group.getCheckedRadioButtonId();
        if (id == -1) return "Normal";
        RadioButton rb = findViewById(id);
        return rb.getText().toString();
    }
}