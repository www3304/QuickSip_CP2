package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvPoints, tvTotalOrders, tvMemberTier, tvNextReward;
    private ProgressBar progressBarPoints;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();

        if (user == null) {
            finish();
            return;
        }

        // Initialize Views
        tvName = findViewById(R.id.tvProfileName);
        tvEmail = findViewById(R.id.tvProfileEmail);
        tvPoints = findViewById(R.id.tvPoints);
        tvTotalOrders = findViewById(R.id.tvTotalOrders);
        tvMemberTier = findViewById(R.id.tvMemberTier);
        tvNextReward = findViewById(R.id.tvNextReward);
        progressBarPoints = findViewById(R.id.progressBarPoints);

        // Setup User Info
        tvName.setText(user.getDisplayName() != null ? user.getDisplayName() : "Coffee Lover");
        tvEmail.setText(user.getEmail());

        // 🔥 CALCULATE REAL POINTS
        calculateLoyaltyPoints(user.getUid());

        // Buttons
        findViewById(R.id.btnEditProfile).setOnClickListener(v -> showEditNameDialog(user));

        // Placeholders for future features
        findViewById(R.id.btnPayment).setOnClickListener(v -> Toast.makeText(this, "Payment Methods coming soon!", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btnAddress).setOnClickListener(v -> Toast.makeText(this, "Address Book coming soon!", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btnHelp).setOnClickListener(v -> Toast.makeText(this, "Support Chat coming soon!", Toast.LENGTH_SHORT).show());

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            mAuth.signOut();
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        setupBottomNav();
    }

    private void calculateLoyaltyPoints(String userId) {
        db.collection("orders")
                .whereEqualTo("userId", userId)
                .whereNotIn("status", java.util.Arrays.asList("CANCELLED")) // Don't count cancelled orders
                .get()
                .addOnSuccessListener(snapshots -> {
                    double totalSpent = 0;
                    int orderCount = 0;

                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            totalSpent += order.getTotalPrice();
                            orderCount++;
                        }
                    }

                    // Logic: 1 Point per RM 1 spent
                    int points = (int) totalSpent;
                    updateLoyaltyUI(points, orderCount);
                });
    }

    private void updateLoyaltyUI(int points, int orderCount) {
        tvPoints.setText(points + " pts");
        tvTotalOrders.setText(String.valueOf(orderCount));

        // Tier Logic
        int maxProgress = 100;
        if (points < 100) {
            tvMemberTier.setText("Green Member");
            tvNextReward.setText("Earn " + (100 - points) + " more pts for Gold");
            maxProgress = 100;
        } else if (points < 300) {
            tvMemberTier.setText("Gold Member 🌟");
            tvNextReward.setText("Earn " + (300 - points) + " more pts for Platinum");
            maxProgress = 300;
        } else {
            tvMemberTier.setText("Platinum Member 💎");
            tvNextReward.setText("You are a top tier member!");
            maxProgress = 1000;
        }

        progressBarPoints.setMax(maxProgress);
        progressBarPoints.setProgress(points);
    }

    private void showEditNameDialog(FirebaseUser user) {
        EditText input = new EditText(this);
        input.setText(user.getDisplayName());

        // Stylize the input slightly (Optional)
        input.setPadding(50, 50, 50, 50);

        new AlertDialog.Builder(this)
                .setTitle("Edit Username")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newName = input.getText().toString();
                    if (!newName.isEmpty()) {
                        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                .setDisplayName(newName)
                                .build();
                        user.updateProfile(profileUpdates)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        tvName.setText(newName);
                                        Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setupBottomNav() {
        findViewById(R.id.navHome).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerHomeActivity.class));
            overridePendingTransition(0, 0);
        });
        findViewById(R.id.navMyOrders).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerOrdersActivity.class));
            overridePendingTransition(0, 0);
        });
    }
}