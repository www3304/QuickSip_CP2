package com.quicksip.cp2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog; // ✅ Using AndroidX for better dialogs
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvPoints, tvMemberTier, tvNextReward;
    private ProgressBar progressBarPoints;
    private FirebaseFirestore db;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        // 1. Initialize Views (Using NEW IDs)
        tvName = findViewById(R.id.tvProfileName);
        tvEmail = findViewById(R.id.tvProfileEmail);
        tvPoints = findViewById(R.id.tvPoints);
        tvMemberTier = findViewById(R.id.tvMemberTier);
        tvNextReward = findViewById(R.id.tvNextReward);
        progressBarPoints = findViewById(R.id.progressBarPoints);

        ImageButton btnEditName = findViewById(R.id.btnEditName);
        Button btnLogout = findViewById(R.id.btnLogout);

        // 2. Load User Data
        if (user != null) {
            userId = user.getUid();
            tvEmail.setText(user.getEmail());
            loadUserProfile();
            calculateLoyaltyPoints(userId); // Load points too!
        }

        // 3. Listeners
        btnEditName.setOnClickListener(v -> showEditNameDialog());

        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        setupBottomNav();
    }

    private void loadUserProfile() {
        if (userId == null) return;
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String name = documentSnapshot.getString("name");
                        tvName.setText(name != null ? name : "QuickSip User");
                    }
                });
    }

    private void calculateLoyaltyPoints(String userId) {
        // Simple logic: 1 order = 10 points (Example)
        db.collection("orders")
                .whereEqualTo("userId", userId)
                .whereEqualTo("status", "COMPLETED")
                .get()
                .addOnSuccessListener(snapshots -> {
                    double totalSpent = 0;
                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) totalSpent += order.getTotalPrice();
                    }

                    int points = (int) totalSpent;
                    tvPoints.setText(points + " pts");
                    progressBarPoints.setProgress(points);

                    if (points < 100) {
                        tvMemberTier.setText("Green Member");
                        tvNextReward.setText("Earn " + (100 - points) + " more pts for Gold");
                    } else {
                        tvMemberTier.setText("Gold Member");
                        tvNextReward.setText("You are a VIP!");
                    }
                });
    }

    private void showEditNameDialog() {
        final EditText input = new EditText(this);
        input.setHint("Enter new name");
        // Add some padding inside the input box so text isn't stuck to the edge
        input.setPadding(60, 40, 60, 40);
        input.setTextColor(Color.BLACK);

        // 1. Build the Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Name");
        builder.setView(input);

        // 2. Set Buttons (Positive = SAVE, Negative = Cancel)
        builder.setPositiveButton("SAVE", (dialog, which) -> {
            String newName = input.getText().toString().trim();
            if (!newName.isEmpty()) {
                updateName(newName);
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        // 3. Create and Show
        AlertDialog dialog = builder.create();
        dialog.show();

        Button btnSave = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button btnCancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);

        // STYLE 1: "SAVE" button -> Solid Green background, White text
        btnSave.setBackgroundColor(Color.parseColor("#00C853"));
        btnSave.setTextColor(Color.WHITE);

        // STYLE 2: "Cancel" button -> Transparent background, Gray text
        btnCancel.setBackgroundColor(Color.WHITE);
        btnCancel.setTextColor(Color.RED);

        // SPACER: Add margin to the left of the Save button to push them apart
        android.widget.LinearLayout.LayoutParams params = (android.widget.LinearLayout.LayoutParams) btnSave.getLayoutParams();
        params.leftMargin = 30; // 30px gap
        btnSave.setLayoutParams(params);
    }

    private void updateName(String newName) {
        if (userId == null) return;
        Map<String, Object> data = new HashMap<>();
        data.put("name", newName);

        db.collection("users").document(userId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    tvName.setText(newName);
                    Toast.makeText(this, "Name updated!", Toast.LENGTH_SHORT).show();
                });
    }

    private void setupBottomNav() {
        findViewById(R.id.navHome).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerHomeActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });
        findViewById(R.id.navMyOrders).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerOrdersActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });
    }
}