package com.quicksip.cp2;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color; // Import for Color
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName;
    private FirebaseFirestore db;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        // 1. Setup Views
        tvName = findViewById(R.id.tvUserName);
        TextView tvEmail = findViewById(R.id.tvUserEmail);
        ImageButton btnEditName = findViewById(R.id.btnEditName);

        // 2. Setup Back Button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // 3. Setup Logout Button (🔥 FIX: Ensure this ID matches XML)
        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            // Clear back stack so they can't go back
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // 4. Load User Data
        if (user != null) {
            userId = user.getUid();
            tvEmail.setText(user.getEmail());
            loadUserProfile();
        }

        // 5. Edit Name Click
        btnEditName.setOnClickListener(v -> showEditNameDialog());

        // 6. Bottom Navigation Listeners
        setupBottomNav();
    }

    private void loadUserProfile() {
        if (userId == null) return;
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String name = documentSnapshot.getString("name");
                        tvName.setText(name != null ? name : "QuickSip User");
                    }
                });
    }

    private void showEditNameDialog() {
        final EditText input = new EditText(this);
        input.setHint("Enter new name");
        input.setPadding(50, 50, 50, 50);
        input.setTextColor(Color.BLACK);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Name")
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    String newName = input.getText().toString().trim();
                    if (!newName.isEmpty()) {
                        updateName(newName);
                    }
                })
                .setNegativeButton("Cancel", null)
                .create();

        dialog.show();

        // 🔥 FIX: Force Button Text Colors to BLACK so they are visible
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.BLACK);
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.GRAY);
    }

    private void updateName(String newName) {
        if (userId == null) return;

        Map<String, Object> data = new HashMap<>();
        data.put("name", newName);

        db.collection("users").document(userId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    tvName.setText(newName);
                    Toast.makeText(this, "Name updated!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void setupBottomNav() {
        findViewById(R.id.navHome).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerHomeActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        findViewById(R.id.navMyOrders).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerOrdersActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        // navProfile does nothing as we are already here
    }
}