package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue; // ✅ Import this
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckoutActivity extends AppCompatActivity {

    private RecyclerView checkoutRecycler;
    private CartAdapter adapter;
    private TextView tvTotal;
    private Button btnPlaceOrder;
    private List<CartItem> checkoutItems;
    private double totalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        // 1. SETUP BACK BUTTON
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 2. SETUP VIEWS
        tvTotal = findViewById(R.id.tvCheckoutTotal);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        checkoutRecycler = findViewById(R.id.checkoutRecycler);

        checkoutRecycler.setLayoutManager(new LinearLayoutManager(this));

        // 3. LOAD DATA
        checkoutItems = CartManager.getInstance().getItems();
        totalPrice = CartManager.getInstance().getTotalPrice();

        adapter = new CartAdapter(checkoutItems, new CartAdapter.OnCartChangeListener() {
            @Override
            public void onItemChanged() {
                totalPrice = CartManager.getInstance().getTotalPrice();
                tvTotal.setText("RM " + String.format("%.2f", totalPrice));
            }
        });
        checkoutRecycler.setAdapter(adapter);

        tvTotal.setText("RM " + String.format("%.2f", totalPrice));

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        if (checkoutItems.isEmpty()) {
            Toast.makeText(this, "Cart is empty!", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Please login first!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Generate visible Order ID
        String visibleOrderId = "QS" + (int)(Math.random() * 90000 + 10000);

        Map<String, Object> orderMap = new HashMap<>();
        orderMap.put("orderId", visibleOrderId);
        orderMap.put("userId", auth.getCurrentUser().getUid());
        orderMap.put("userEmail", auth.getCurrentUser().getEmail());
        orderMap.put("items", checkoutItems);
        orderMap.put("totalPrice", totalPrice);
        orderMap.put("status", "NEW");
        // ✅ FIX: Use Server Timestamp (Best for sorting)
        orderMap.put("timeStamp", FieldValue.serverTimestamp());

        FirebaseFirestore.getInstance().collection("orders")
                .add(orderMap)
                .addOnSuccessListener(documentReference -> {
                    CartManager.getInstance().clear();
                    Toast.makeText(this, "Order Placed Successfully!", Toast.LENGTH_SHORT).show();

                    // Redirect to "My Orders"
                    Intent intent = new Intent(this, CustomerOrdersActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to place order.", Toast.LENGTH_SHORT).show();
                });
    }
}