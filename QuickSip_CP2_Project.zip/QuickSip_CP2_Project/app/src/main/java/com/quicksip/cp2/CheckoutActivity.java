package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.List;

public class CheckoutActivity extends AppCompatActivity {

    private RecyclerView checkoutRecycler;
    private CheckoutAdapter adapter;
    private TextView tvTotal;
    private Button btnPlaceOrder;
    private List<CartItem> checkoutItems;
    private double totalPrice = 0;
    private RadioGroup radioGroupCollectMethod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        checkoutRecycler = findViewById(R.id.recyclerCheckout);
        tvTotal = findViewById(R.id.tvCheckoutTotal);
        btnPlaceOrder = findViewById(R.id.btnConfirmOrder);
        ImageButton btnBack = findViewById(R.id.btnBack);

        radioGroupCollectMethod = findViewById(R.id.radioGroupCollectMethod);

        // --- FIX: Use the IDs from your XML file (rbPickup, rbDineIn) ---
        RadioButton radioPickUp = findViewById(R.id.rbPickup); // Changed from radioPickUp
        RadioButton radioDineIn = findViewById(R.id.rbDineIn); // Changed from radioDineIn

        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        checkoutRecycler.setLayoutManager(new LinearLayoutManager(this));
        checkoutItems = new ArrayList<>(CartManager.getInstance().getItems());

        adapter = new CheckoutAdapter(checkoutItems);
        checkoutRecycler.setAdapter(adapter);

        calculateTotal();

        // --- SYNC WITH CART MANAGER ---
        String savedMethod = CartManager.getInstance().getOrderMethod();

        if ("Dine-in".equalsIgnoreCase(savedMethod)) {
            radioDineIn.setChecked(true);
        } else {
            radioPickUp.setChecked(true);
        }

        radioGroupCollectMethod.setOnCheckedChangeListener((group, checkedId) -> {
            // --- FIX: Use the correct ID here too ---
            if (checkedId == R.id.rbDineIn) {
                CartManager.getInstance().setOrderMethod("Dine-in");
            } else {
                CartManager.getInstance().setOrderMethod("Pick-Up");
            }
        });

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void calculateTotal() {
        totalPrice = 0;
        for (CartItem item : checkoutItems) {
            totalPrice += (item.getFinalPrice() * item.getQuantity());
        }
        tvTotal.setText("Total: RM " + String.format("%.2f", totalPrice));
    }

    private void placeOrder() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        if (checkoutItems.isEmpty()) {
            Toast.makeText(this, "Your cart is empty!", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedId = radioGroupCollectMethod.getCheckedRadioButtonId();
        RadioButton selectedRadioButton = findViewById(selectedId);

        String tempMethod = "Pick-Up";
        if (selectedRadioButton != null) {
            tempMethod = selectedRadioButton.getText().toString();
        }
        final String collectMethod = tempMethod;

        Order order = new Order(
                user.getUid(),
                user.getEmail(),
                checkoutItems,
                totalPrice,
                "NEW",
                collectMethod
        );

        FirebaseFirestore.getInstance().collection("orders")
                .add(order)
                .addOnSuccessListener(doc -> {
                    Toast.makeText(this, "Order Placed: " + collectMethod, Toast.LENGTH_SHORT).show();
                    CartManager.getInstance().clearCart();

                    Intent intent = new Intent(CheckoutActivity.this, CustomerOrdersActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to place order", Toast.LENGTH_SHORT).show();
                });
    }
}