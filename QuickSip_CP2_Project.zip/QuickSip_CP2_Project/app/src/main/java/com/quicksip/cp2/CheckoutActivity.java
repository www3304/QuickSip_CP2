package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class CheckoutActivity extends AppCompatActivity {

    private RecyclerView checkoutRecycler;
    private CheckoutAdapter adapter;
    private TextView tvTotal;
    private Button btnPlaceOrder;
    private List<CartItem> checkoutItems;
    private double totalPrice = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        checkoutRecycler = findViewById(R.id.recyclerCheckout);
        tvTotal = findViewById(R.id.tvCheckoutTotal);
        btnPlaceOrder = findViewById(R.id.btnConfirmOrder);
        ImageButton btnBack = findViewById(R.id.btnBack);

        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        checkoutRecycler.setLayoutManager(new LinearLayoutManager(this));

        // ✅ Load items directly from CartManager
        checkoutItems = new ArrayList<>(CartManager.getInstance().getItems());

        adapter = new CheckoutAdapter(checkoutItems);
        checkoutRecycler.setAdapter(adapter);

        calculateTotal();

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void calculateTotal() {
        totalPrice = 0;
        for (CartItem item : checkoutItems) {
            totalPrice += (item.getFinalPrice() * item.getQuantity());
        }
        tvTotal.setText("Total: RM " + String.format("%.2f", totalPrice));
    }

    private void placeOrder() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        // Create Order Object
        Order order = new Order(
                user.getUid(),
                user.getEmail(),
                checkoutItems,
                totalPrice
        );

        FirebaseFirestore.getInstance().collection("orders")
                .add(order)
                .addOnSuccessListener(doc -> {
                    Toast.makeText(this, "Order Placed Successfully!", Toast.LENGTH_SHORT).show();
                    CartManager.getInstance().clearCart(); // Clear local cart

                    // Go to Orders Page
                    Intent intent = new Intent(CheckoutActivity.this, CustomerOrdersActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to place order", Toast.LENGTH_SHORT).show();
                });
    }
}