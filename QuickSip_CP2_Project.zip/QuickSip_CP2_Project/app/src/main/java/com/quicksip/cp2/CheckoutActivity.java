package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckoutActivity extends AppCompatActivity {

    private RecyclerView checkoutRecycler;
    private CartAdapter adapter;
    private TextView tvTotal;
    private Button btnPlaceOrder;
    private List<CartItem> checkoutItems;
    private double totalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        // 1. SETUP BACK BUTTON
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 2. SETUP VIEWS
        tvTotal = findViewById(R.id.tvCheckoutTotal);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        checkoutRecycler = findViewById(R.id.checkoutRecycler);

        checkoutRecycler.setLayoutManager(new LinearLayoutManager(this));

        // 3. LOAD DATA (Fixed method names here)
        checkoutItems = CartManager.getInstance().getItems(); // Was getCartItems()
        totalPrice = CartManager.getInstance().getTotalPrice();

        // 4. SETUP ADAPTER (Fixed interface method name)
        adapter = new CartAdapter(checkoutItems, new CartAdapter.OnCartChangeListener() {
            @Override
            public void onItemChanged() { // Was onQuantityChanged()
                // If user changes qty in checkout, update the total price displayed
                totalPrice = CartManager.getInstance().getTotalPrice();
                tvTotal.setText("RM " + String.format("%.2f", totalPrice));
            }
        });
        checkoutRecycler.setAdapter(adapter);

        tvTotal.setText("RM " + String.format("%.2f", totalPrice));

        // 5. PLACE ORDER LOGIC
        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        if (checkoutItems.isEmpty()) return;

        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) return;

        Map<String, Object> orderMap = new HashMap<>();
        orderMap.put("userId", auth.getCurrentUser().getUid());
        orderMap.put("userEmail", auth.getCurrentUser().getEmail());
        orderMap.put("items", checkoutItems);
        orderMap.put("totalPrice", totalPrice);
        orderMap.put("status", "NEW");
        orderMap.put("timeStamp", com.google.firebase.Timestamp.now().toDate().toString());

        FirebaseFirestore.getInstance().collection("orders")
                .add(orderMap)
                .addOnSuccessListener(documentReference -> {
                    // Success: Clear cart using the correct method name
                    CartManager.getInstance().clear(); // Was clearCart()

                    Toast.makeText(this, "Order Placed Successfully!", Toast.LENGTH_SHORT).show();

                    // Redirect to "My Orders"
                    Intent intent = new Intent(this, CustomerOrdersActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to place order.", Toast.LENGTH_SHORT).show();
                });
    }
}