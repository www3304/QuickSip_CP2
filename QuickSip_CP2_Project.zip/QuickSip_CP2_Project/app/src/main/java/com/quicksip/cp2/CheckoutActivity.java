package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class CheckoutActivity extends AppCompatActivity {

    private RecyclerView checkoutRecycler;
    private TextView tvCheckoutTotal;
    private Button btnPlaceOrder;

    private CartAdapter adapter;
    private List<CartItem> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("FIRESTORE", "🔥🔥🔥 CHECKOUT ACTIVITY OPENED 🔥🔥🔥");
        setContentView(R.layout.activity_checkout);

        checkoutRecycler = findViewById(R.id.checkoutRecycler);
        tvCheckoutTotal = findViewById(R.id.tvCheckoutTotal);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);


        // 🔥 DEFENSIVE COPY (IMPORTANT)
        cartItems = new ArrayList<>(CartManager.getInstance().getItems());
        Log.d("FIRESTORE", "Checkout cart size = " + cartItems.size());

        adapter = new CartAdapter(cartItems, this::updateTotal);
        checkoutRecycler.setLayoutManager(new LinearLayoutManager(this));
        checkoutRecycler.setAdapter(adapter);

        updateTotal();

        btnPlaceOrder.setOnClickListener(v -> {
            Log.d("FIRESTORE", "Place Order button clicked");
            placeOrder();
        });
    }

    private void placeOrder() {

        Log.d("FIRESTORE", "placeOrder() entered");

        if (cartItems.isEmpty()) {
            Log.d("FIRESTORE", "Cart is empty, aborting order");
            Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Log.d("FIRESTORE", "User is null, aborting order");
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }

        Order order = new Order(
                user.getUid(),
                cartItems,
                CartManager.getInstance().getTotalPrice()
        );

        FirebaseFirestore.getInstance()
                .collection("orders")
                .add(order)
                .addOnSuccessListener(ref -> {

                    // 🔥 SAVE FIRESTORE DOC ID INTO ORDER
                    order.setFirestoreId(ref.getId());

                    // OPTIONAL: write it back so others can read it
                    ref.update("firestoreId", ref.getId());

                    CartManager.getInstance().clear();

                    Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, CustomerOrdersActivity.class));
                    finish();
                });
    }

    private void updateTotal() {
        double total = CartManager.getInstance().getTotalPrice();
        tvCheckoutTotal.setText("Total: RM " + String.format("%.2f", total));
    }
}
