package com.quicksip.cp2;

import com.google.firebase.firestore.Exclude;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;
import java.util.List;

public class Order {
    private String orderId;
    private String userId;
    private String userEmail;
    private List<CartItem> items;
    private double totalPrice;
    private String status;
    private String collectMethod;

    @ServerTimestamp
    private Date timestamp;

    // 1. Empty Constructor (Required for Firebase)
    public Order() {}

    // 2. Full Constructor
    public Order(String userId, String userEmail, List<CartItem> items, double totalPrice, String status, String collectMethod) {
        this.userId = userId;
        this.userEmail = userEmail;
        this.items = items;
        this.totalPrice = totalPrice;
        this.status = status;
        this.collectMethod = collectMethod;
    }

    // --- GETTERS & SETTERS ---
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    @Exclude // <--- ADD THIS
    public String getFirestoreId() { return orderId; }
    @Exclude // <--- ADD THIS
    public void setFirestoreId(String id) { this.orderId = id; }

    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
    @Exclude // <--- ADD THIS
    public Date getTimeStamp() { return timestamp; }

    // --- Standard Getters ---
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public List<CartItem> getItems() { return items; }
    public void setItems(List<CartItem> items) { this.items = items; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCollectMethod() { return collectMethod; }
    public void setCollectMethod(String collectMethod) { this.collectMethod = collectMethod; }
}