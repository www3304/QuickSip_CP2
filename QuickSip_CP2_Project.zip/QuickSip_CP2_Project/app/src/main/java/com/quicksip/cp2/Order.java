package com.quicksip.cp2;

import com.google.firebase.Timestamp;
import java.util.List;

public class Order {
    private String orderId;
    private String userId;
    private String userEmail;
    private List<CartItem> items; // <--- WAS CartItem
    private double totalPrice;
    private String status;
    private Timestamp timeStamp;

    public Order() { }

    public Order(String userId, String userEmail, List<CartItem> items, double totalPrice) { // <--- WAS CartItem
        this.userId = userId;
        this.userEmail = userEmail;
        this.items = items;
        this.totalPrice = totalPrice;
        this.status = "New";
        this.timeStamp = Timestamp.now();
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getUserId() { return userId; }
    public String getUserEmail() { return userEmail; }

    public List<CartItem> getItems() { return items; } // <--- WAS CartItem
    public void setItems(List<CartItem> items) { this.items = items; } // <--- WAS CartItem

    public double getTotalPrice() { return totalPrice; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Timestamp getTimeStamp() { return timeStamp; }
    // Add these inside Order.java
    public String getFirestoreId() { return orderId; }
    public void setFirestoreId(String id) { this.orderId = id; }
}