package com.quicksip.cp2;

import java.util.List;

public class Order {

    private String orderId;
    private String userId;
    private String timeStamp;
    private List<CartItem> items;
    private double totalPrice;
    private String status;
    private boolean notified;
    private String firestoreId;


    // 🔥 REQUIRED empty constructor
    public Order() {}

    public Order(String userId, List<CartItem> items, double totalPrice) {
        this.userId = userId;
        this.items = items;
        this.totalPrice = totalPrice;
        this.status = "NEW";
        this.notified = false;
        this.orderId = "QS" + (int)(Math.random() * 90000 + 10000);
        this.timeStamp = System.currentTimeMillis() + "";
    }

    // -------- GETTERS & SETTERS (REQUIRED) --------

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isNotified() {
        return notified;
    }

    public void setNotified(boolean notified) {
        this.notified = notified;
    }

    public String getFirestoreId() {
        return firestoreId;
    }

    public void setFirestoreId(String firestoreId) {
        this.firestoreId = firestoreId;
    }
}
