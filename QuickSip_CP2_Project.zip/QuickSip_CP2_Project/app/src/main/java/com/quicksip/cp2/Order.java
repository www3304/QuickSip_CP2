package com.quicksip.cp2;

import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {

    private String orderId;      // Visible ID (e.g., "QS12345")
    private String firestoreId;  // Internal Firestore Document ID
    private String userId;
    private String userEmail;    // ✅ Added to fix the warning
    private Object timeStamp;    // ✅ Changed to Object (Fixes the Crash!)
    private List<CartItem> items;
    private double totalPrice;
    private String status;

    // 🔥 REQUIRED empty constructor for Firestore
    public Order() {}

    public Order(String userId, String userEmail, List<CartItem> items, double totalPrice) {
        this.userId = userId;
        this.userEmail = userEmail;
        this.items = items;
        this.totalPrice = totalPrice;
        this.status = "NEW";
        this.orderId = "QS" + (int)(Math.random() * 90000 + 10000);
        this.timeStamp = com.google.firebase.Timestamp.now();
    }

    // Getters & Setters
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getFirestoreId() { return firestoreId; }
    public void setFirestoreId(String firestoreId) { this.firestoreId = firestoreId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUserEmail() { return userEmail; } // ✅ New Getter
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; } // ✅ New Setter

    public Object getTimeStamp() { return timeStamp; } // ✅ Returns Object now
    public void setTimeStamp(Object timeStamp) { this.timeStamp = timeStamp; }

    public List<CartItem> getItems() { return items; }
    public void setItems(List<CartItem> items) { this.items = items; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}