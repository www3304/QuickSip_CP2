package com.quicksip.cp2;

import java.util.ArrayList;
import java.util.List;

public class OrderManager {

    private static OrderManager instance;
    private List<Order> orderList = new ArrayList<>();

    private OrderManager() {}

    public static OrderManager getInstance() {
        if (instance == null) {
            instance = new OrderManager();
        }
        return instance;
    }

    public void addOrder(Order order) {
        orderList.add(order);
    }

    public List<Order> getOrders() {
        return orderList;
    }

    public void updateOrderStatus(Order order, String newStatus) {
        order.setStatus(newStatus);
    }

    public void removeOrder(Order order) {
        orderList.remove(order);
    }
}
