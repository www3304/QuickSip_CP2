package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomerOrderAdapter extends RecyclerView.Adapter<CustomerOrderAdapter.OrderViewHolder> {

    private final List<Order> orders;

    public CustomerOrderAdapter(List<Order> orders) {
        this.orders = orders;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_customer_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        // 🛡️ 1. SAFETY CHECK: If order is null, stop.
        if (order == null) return;

        // 🛡️ 2. SAFE STRINGS: Use default values if data is missing
        String id = order.getOrderId() != null ? order.getOrderId() : "Unknown";
        String time = order.getTimeStamp() != null ? order.getTimeStamp() : "";
        String status = order.getStatus() != null ? order.getStatus() : "NEW";
        double total = order.getTotalPrice();

        holder.tvOrderId.setText("Order #" + id);
        holder.tvTime.setText(time);
        holder.tvTotal.setText("Total: RM " + String.format("%.2f", total));
        holder.tvStatus.setText("Status: " + status);

        // 🎨 Color Logic
        int color;
        switch (status) {
            case "PREPARING":
                color = Color.parseColor("#FFA726"); // Orange
                break;
            case "READY":
                color = Color.parseColor("#66BB6A"); // Green
                break;
            case "COMPLETED":
                color = Color.GRAY;
                break;
            default: // "NEW"
                color = Color.BLUE;
                break;
        }
        holder.tvStatus.setTextColor(color);

        // 🛡️ 3. SAFE LIST LOOP: Check if items list is null before looping!
        StringBuilder summary = new StringBuilder();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                summary.append(item.getQuantity())
                        .append("x ")
                        .append(item.getDrinkName())
                        .append(", ");
            }
        } else {
            summary.append("No items details");
        }

        // Remove last comma
        if (summary.length() > 2) {
            summary.setLength(summary.length() - 2);
        }

        holder.tvItems.setText(summary.toString());
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvTime, tvItems, tvTotal, tvStatus;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvItems = itemView.findViewById(R.id.tvItems);
            tvTotal = itemView.findViewById(R.id.tvTotal);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}