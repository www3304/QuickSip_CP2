package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp; // ✅ Import this

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class CustomerOrderAdapter extends RecyclerView.Adapter<CustomerOrderAdapter.OrderViewHolder> {

    private final List<Order> orders;

    public CustomerOrderAdapter(List<Order> orders) {
        this.orders = orders;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_customer_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);
        if (order == null) return;

        // 1. DATA SETUP
        String id = order.getOrderId() != null ? order.getOrderId() : "Unknown";
        String status = order.getStatus() != null ? order.getStatus() : "NEW";
        double total = order.getTotalPrice();

        // 🔥 2. SMART DATE FORMATTING
        String time = "Just Now";
        if (order.getTimeStamp() != null) {
            try {
                Object ts = order.getTimeStamp();
                if (ts instanceof Timestamp) {
                    // It's a Firestore Timestamp (New Orders)
                    time = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                            .format(((Timestamp) ts).toDate());
                } else if (ts instanceof String) {
                    // It's a String (Old Orders)
                    time = (String) ts;
                    // Try to shorten it if it's the long standard Java date string
                    if (time.length() > 10) time = time.substring(0, 16);
                }
            } catch (Exception e) {
                time = "Unknown Time";
            }
        }

        // 3. SET TEXT
        holder.tvOrderId.setText("Order #" + id);
        holder.tvTime.setText(time);
        holder.tvTotal.setText("Total: RM " + String.format("%.2f", total));
        holder.tvStatus.setText("Status: " + status);

        // 4. COLOR LOGIC
        int color;
        switch (status) {
            case "PREPARING": color = Color.parseColor("#FFA726"); break; // Orange
            case "READY":     color = Color.parseColor("#66BB6A"); break; // Green
            case "COMPLETED": color = Color.GRAY; break;
            case "CANCELLED": color = Color.RED; break;
            default:          color = Color.BLUE; break; // "NEW"
        }
        holder.tvStatus.setTextColor(color);

        // 5. ITEMS SUMMARY
        StringBuilder summary = new StringBuilder();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                summary.append(item.getQuantity())
                        .append("x ")
                        .append(item.getDrinkName())
                        .append(", ");
            }
        }
        if (summary.length() > 2) summary.setLength(summary.length() - 2);
        holder.tvItems.setText(summary.toString());
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvTime, tvItems, tvTotal, tvStatus;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvItems = itemView.findViewById(R.id.tvItems);
            tvTotal = itemView.findViewById(R.id.tvTotal);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}