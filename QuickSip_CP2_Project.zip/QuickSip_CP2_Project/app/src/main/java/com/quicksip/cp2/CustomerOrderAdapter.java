package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomerOrderAdapter extends RecyclerView.Adapter<CustomerOrderAdapter.OrderViewHolder> {

    private final List<Order> orders;

    public CustomerOrderAdapter(List<Order> orders) {
        this.orders = orders;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_customer_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        if (order == null) return;

        // 🛡️ 1. SAFE DATA HANDLING
        String id = order.getOrderId() != null ? order.getOrderId() : "Unknown";
        String status = order.getStatus() != null ? order.getStatus() : "NEW";
        double total = order.getTotalPrice();

        // 🔥 FIX: Handle Timestamp (Object -> String)
        String time = "Just Now";
        if (order.getTimeStamp() != null) {
            time = order.getTimeStamp().toString();
            // Note: If you want a pretty date later, we can format this Date object.
        }

        holder.tvOrderId.setText("Order #" + id); // Usually Firestore ID is long, maybe use substring if needed
        holder.tvTime.setText(time);
        holder.tvTotal.setText("Total: RM " + String.format("%.2f", total));
        holder.tvStatus.setText("Status: " + status);

        // 🎨 2. COLOR LOGIC
        int color;
        switch (status) {
            case "PREPARING":
                color = Color.parseColor("#FFA726"); // Orange
                break;
            case "READY":
                color = Color.parseColor("#66BB6A"); // Green
                break;
            case "COMPLETED":
                color = Color.GRAY;
                break;
            default: // "NEW"
                color = Color.BLUE;
                break;
        }
        holder.tvStatus.setTextColor(color);

        // 🛡️ 3. ITEMS SUMMARY
        StringBuilder summary = new StringBuilder();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                summary.append(item.getQuantity())
                        .append("x ")
                        .append(item.getDrinkName())
                        .append(", ");
            }
        } else {
            summary.append("No items details");
        }

        if (summary.length() > 2) {
            summary.setLength(summary.length() - 2);
        }

        holder.tvItems.setText(summary.toString());
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvTime, tvItems, tvTotal, tvStatus;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvItems = itemView.findViewById(R.id.tvItems);
            tvTotal = itemView.findViewById(R.id.tvTotal);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}