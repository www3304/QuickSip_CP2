package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomerOrderAdapter extends RecyclerView.Adapter<CustomerOrderAdapter.OrderViewHolder> {

    private final List<Order> orders;

    public CustomerOrderAdapter(List<Order> orders) {
        this.orders = orders;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_customer_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        holder.tvOrderId.setText("Order #" + order.getOrderId());
        holder.tvTime.setText(order.getTimeStamp());
        holder.tvTotal.setText("Total: RM " + String.format("%.2f", order.getTotalPrice()));
        holder.tvStatus.setText("Status: " + order.getStatus());

        // Build item summary
        StringBuilder summary = new StringBuilder();
        for (CartItem item : order.getItems()) {
            summary.append(item.getQuantity())
                    .append("x ")
                    .append(item.getDrinkName())
                    .append(", ");
        }

        if (summary.length() > 2) {
            summary.setLength(summary.length() - 2);
        }

        holder.tvItems.setText(summary.toString());
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvTime, tvItems, tvTotal, tvStatus;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvItems = itemView.findViewById(R.id.tvItems);
            tvTotal = itemView.findViewById(R.id.tvTotal);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}
