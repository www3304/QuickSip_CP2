package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;

public class KitchenOrdersActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter;
    private List<Order> allOrders = new ArrayList<>();
    private List<Order> displayedOrders = new ArrayList<>();
    private Button btnTabNew, btnTabPreparing, btnTabReady;
    private String currentStatusFilter = "NEW";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null || !UserRoleManager.isAdmin(user)) {
            finish();
            return;
        }

        setContentView(R.layout.activity_kitchen_orders);

        btnTabNew = findViewById(R.id.btnTabNew);
        btnTabPreparing = findViewById(R.id.btnTabPreparing);
        btnTabReady = findViewById(R.id.btnTabReady);
        recyclerView = findViewById(R.id.kitchenRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new KitchenOrderAdapter(displayedOrders, false, new KitchenOrderAdapter.OnKitchenActionListener() {
            @Override
            public void onStatusChange(int position, String newStatus) {
                updateOrderStatus(position, newStatus);
            }
            @Override
            public void onMarkCompleted(int position) {
                updateOrderStatus(position, "COMPLETED");
            }
            @Override
            public void onCancelOrder(int position) {
                updateOrderStatus(position, "CANCELLED");
            }
        });
        recyclerView.setAdapter(adapter);

        btnTabNew.setOnClickListener(v -> setFilter("NEW"));
        btnTabPreparing.setOnClickListener(v -> setFilter("PREPARING"));
        btnTabReady.setOnClickListener(v -> setFilter("READY"));

        setFilter("NEW");

        FirebaseFirestore.getInstance()
                .collection("orders")
                // Filter out finished orders so they leave the kitchen view instantly
                .whereNotIn("status", java.util.Arrays.asList("COMPLETED", "CANCELLED"))
                .orderBy("status")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.e("KitchenError", "Listen failed.", e);
                        return;
                    }

                    if (snapshots != null) {
                        allOrders.clear();
                        for (DocumentSnapshot doc : snapshots) {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setFirestoreId(doc.getId()); // Use setFirestoreId for the admin adapter
                                allOrders.add(order);
                            }
                        }
                        applyFilter(); // Refreshes the UI tabs
                    }
                });

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_kitchen);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) {
                startActivity(new Intent(this, AdminDashboardActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (id == R.id.nav_history) {
                startActivity(new Intent(this, AdminHistoryActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return id == R.id.nav_kitchen;
        });
    }

    private void setFilter(String status) {
        currentStatusFilter = status;
        btnTabNew.setSelected(status.equals("NEW"));
        btnTabPreparing.setSelected(status.equals("PREPARING"));
        btnTabReady.setSelected(status.equals("READY"));
        applyFilter();
    }

    private void applyFilter() {
        displayedOrders.clear();
        for (Order order : allOrders) {
            String s = order.getStatus() != null ? order.getStatus().toUpperCase() : "NEW";
            if (s.equals(currentStatusFilter)) {
                displayedOrders.add(order);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void updateOrderStatus(int position, String status) {
        if (position >= displayedOrders.size()) return;
        Order order = displayedOrders.get(position);
        if (order.getFirestoreId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("orders")
                .document(order.getFirestoreId())
                .update("status", status)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Order Updated to " + status, Toast.LENGTH_SHORT).show());
    }
}