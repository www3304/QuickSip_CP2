package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class KitchenOrdersActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter;
    private List<Order> kitchenOrders = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 🔐 ADMIN PROTECTION
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (!UserRoleManager.isAdmin(user)) {
            finish(); // block non-admin access
            return;
        }

        setContentView(R.layout.activity_kitchen_orders);

        FirebaseFirestore.getInstance()
                .collection("orders")
                .orderBy("timeStamp", Query.Direction.DESCENDING);

        Button btnLogout = findViewById(R.id.btnKitchenLogout);

        btnLogout.setOnClickListener(v -> {
            // 🔐 Firebase logout
            FirebaseAuth.getInstance().signOut();

            // 🔁 Go back to Login page
            Intent intent = new Intent(KitchenOrdersActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            finish(); // close admin page
        });

        recyclerView = findViewById(R.id.kitchenRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereNotEqualTo("status", "COMPLETED")
                .orderBy("status")
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    kitchenOrders.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            // ✅ FIX: This line is REQUIRED to update status later!
                            order.setFirestoreId(doc.getId());
                            kitchenOrders.add(order);
                        }
                    }
                    adapter.notifyDataSetChanged();
                });

        adapter = new KitchenOrderAdapter(
                kitchenOrders,
                new KitchenOrderAdapter.OnKitchenActionListener() {

                    @Override
                    public void onStatusChange(int position, String newStatus) {

                        Order order = kitchenOrders.get(position); // ✅ HERE

                        FirebaseFirestore.getInstance()
                                .collection("orders")
                                .document(order.getFirestoreId())
                                .update("status", newStatus)
                                .addOnSuccessListener(aVoid ->
                                        Log.d("FIRESTORE", "Status updated to " + newStatus)
                                )
                                .addOnFailureListener(e ->
                                        Log.e("FIRESTORE", "Failed to update status", e)
                                );
                    }

                    @Override
                    public void onMarkCompleted(int position) {

                        Order order = kitchenOrders.get(position); // ✅ HERE TOO

                        FirebaseFirestore.getInstance()
                                .collection("orders")
                                .document(order.getOrderId())
                                .update("status", "COMPLETED");
                    }
                }
        );
        recyclerView.setAdapter(adapter);
    }
}
