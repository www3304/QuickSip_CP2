package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class KitchenOrdersActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter;
    private List<Order> kitchenOrders = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🔐 ADMIN CHECK
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null || !UserRoleManager.isAdmin(user)) {
            finish();
            return;
        }

        setContentView(R.layout.activity_kitchen_orders);

        // ⬅️ BACK BUTTON
        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 🗑️ LOGOUT LOGIC REMOVED HERE

        recyclerView = findViewById(R.id.kitchenRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 🔥 FIRESTORE LISTENER (Active Orders Only)
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereNotIn("status", java.util.Arrays.asList("COMPLETED", "CANCELLED"))
                .orderBy("status")
                .orderBy("timeStamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    kitchenOrders.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        try {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setFirestoreId(doc.getId());
                                kitchenOrders.add(order);
                            }
                        } catch (Exception ex) {
                            Log.e("KitchenOrders", "Error parsing order", ex);
                        }
                    }
                    adapter.notifyDataSetChanged();
                });

        // 🛠️ ADAPTER SETUP (Buttons Visible)
        adapter = new KitchenOrderAdapter(
                kitchenOrders,
                false,
                new KitchenOrderAdapter.OnKitchenActionListener() {

                    @Override
                    public void onStatusChange(int position, String newStatus) {
                        updateOrderStatus(position, newStatus);
                    }

                    @Override
                    public void onMarkCompleted(int position) {
                        updateOrderStatus(position, "COMPLETED");
                    }

                    @Override
                    public void onCancelOrder(int position) {
                        updateOrderStatus(position, "CANCELLED");
                        Toast.makeText(KitchenOrdersActivity.this, "Order Cancelled", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        recyclerView.setAdapter(adapter);
    }

    private void updateOrderStatus(int position, String status) {
        if (position >= kitchenOrders.size()) return;

        Order order = kitchenOrders.get(position);
        if (order.getFirestoreId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("orders")
                .document(order.getFirestoreId())
                .update("status", status);
    }
}