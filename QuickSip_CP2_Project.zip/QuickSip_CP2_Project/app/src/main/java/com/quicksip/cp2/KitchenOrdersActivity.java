package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class KitchenOrdersActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KitchenOrderAdapter adapter;
    private List<Order> allOrders = new ArrayList<>(); // Stores EVERYTHING
    private List<Order> displayedOrders = new ArrayList<>(); // Stores only filtered

    private Button btnTabNew, btnTabPreparing, btnTabReady;
    private String currentStatusFilter = "NEW"; // Default

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null || !UserRoleManager.isAdmin(user)) {
            finish();
            return;
        }

        setContentView(R.layout.activity_kitchen_orders);

        // 1. Init Views
        btnTabNew = findViewById(R.id.btnTabNew);
        btnTabPreparing = findViewById(R.id.btnTabPreparing);
        btnTabReady = findViewById(R.id.btnTabReady);
        recyclerView = findViewById(R.id.kitchenRecycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 2. Setup Adapter
        adapter = new KitchenOrderAdapter(displayedOrders, false, new KitchenOrderAdapter.OnKitchenActionListener() {
            @Override
            public void onStatusChange(int position, String newStatus) {
                updateOrderStatus(position, newStatus);
            }
            @Override
            public void onMarkCompleted(int position) {
                updateOrderStatus(position, "COMPLETED");
            }
            @Override
            public void onCancelOrder(int position) {
                updateOrderStatus(position, "CANCELLED");
            }
        });
        recyclerView.setAdapter(adapter);

        // 3. Tab Listeners
        btnTabNew.setOnClickListener(v -> setFilter("NEW"));
        btnTabPreparing.setOnClickListener(v -> setFilter("PREPARING"));
        btnTabReady.setOnClickListener(v -> setFilter("READY"));

        setFilter("NEW"); // Init UI

        // 4. Firestore Listener (Get all active orders)
        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereNotIn("status", java.util.Arrays.asList("COMPLETED", "CANCELLED"))
                .orderBy("status")
                .orderBy("timeStamp", Query.Direction.ASCENDING) // Oldest first for kitchen
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    allOrders.clear();
                    for (DocumentSnapshot doc : snapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            order.setFirestoreId(doc.getId());
                            allOrders.add(order);
                        }
                    }
                    applyFilter(); // Refresh list based on current tab
                });

        // 5. Bottom Nav
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_kitchen);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_dashboard) {
                startActivity(new Intent(this, AdminDashboardActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (id == R.id.nav_history) {
                startActivity(new Intent(this, AdminHistoryActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return id == R.id.nav_kitchen;
        });
    }

    private void setFilter(String status) {
        currentStatusFilter = status;

        // UI Updates (Highlight selected button)
        btnTabNew.setSelected(status.equals("NEW"));
        btnTabPreparing.setSelected(status.equals("PREPARING"));
        btnTabReady.setSelected(status.equals("READY"));

        applyFilter();
    }

    private void applyFilter() {
        displayedOrders.clear();
        for (Order order : allOrders) {
            String s = order.getStatus() != null ? order.getStatus().toUpperCase() : "NEW";
            // Normalizing: "New" -> "NEW"

            if (s.equals(currentStatusFilter)) {
                displayedOrders.add(order);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void updateOrderStatus(int position, String status) {
        if (position >= displayedOrders.size()) return;
        Order order = displayedOrders.get(position);
        if (order.getFirestoreId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("orders")
                .document(order.getFirestoreId())
                .update("status", status)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Order Updated to " + status, Toast.LENGTH_SHORT).show());
    }
}