package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp; // ✅ IMPORT ADDED

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;
    private OnOrderClickListener listener;

    public interface OnOrderClickListener {
        void onOrderAction(Order order, boolean isNext);
    }

    public OrderAdapter(List<Order> orderList, OnOrderClickListener listener) {
        this.orderList = orderList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);

        holder.tvOrderId.setText("Order #" + order.getOrderId());

        // ✅ FIXED: Crash fix for timestamp
        if (order.getTimeStamp() != null) {
            // Check if it's already a Timestamp object (Firebase default)
            if (order.getTimeStamp() instanceof Timestamp) {
                Timestamp ts = (Timestamp) order.getTimeStamp();
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault());
                holder.tvDate.setText(sdf.format(ts.toDate()));
            }
        }

        // ✅ FIXED: "Status: NEW" format restored
        String status = order.getStatus() != null ? order.getStatus().toUpperCase() : "NEW";
        holder.tvStatus.setText("Status: " + status);
        setStatusColor(holder.tvStatus, status);

        // Build Items String
        StringBuilder itemsStr = new StringBuilder();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                itemsStr.append(item.getQuantity()).append("x ").append(item.getDrinkName());
                if(item.getSize() != null && item.getSize().equalsIgnoreCase("Large")) itemsStr.append(" (L)");
                if(item.getToppings() != null && !item.getToppings().isEmpty()){
                    itemsStr.append(" + ").append(item.getToppings());
                }
                itemsStr.append("\n");
            }
        }
        holder.tvItems.setText(itemsStr.toString().trim());

        // Price
        holder.tvTotal.setText("Total: RM " + String.format("%.2f", order.getTotalPrice()));

        // Hide buttons for Customers
        if (listener == null) {
            if(holder.btnNext != null) holder.btnNext.setVisibility(View.GONE);
            if(holder.btnCancel != null) holder.btnCancel.setVisibility(View.GONE);
        } else {
            // Show for Admin
            if(holder.btnNext != null) {
                holder.btnNext.setVisibility(View.VISIBLE);
                configureNextButton(holder.btnNext, status);
                holder.btnNext.setOnClickListener(v -> listener.onOrderAction(order, true));
            }
            if(holder.btnCancel != null) {
                holder.btnCancel.setVisibility(View.VISIBLE);
                holder.btnCancel.setOnClickListener(v -> listener.onOrderAction(order, false));
            }

            if("COMPLETED".equals(status) || "CANCELLED".equals(status)) {
                if(holder.btnNext != null) holder.btnNext.setVisibility(View.GONE);
                if(holder.btnCancel != null) holder.btnCancel.setVisibility(View.GONE);
            }
        }
    }

    private void setStatusColor(TextView tv, String status) {
        switch (status) {
            case "NEW": tv.setTextColor(Color.BLUE); break;
            case "PREPARING": tv.setTextColor(Color.parseColor("#FFA500")); break;
            case "READY": tv.setTextColor(Color.parseColor("#006400")); break;
            case "COMPLETED": tv.setTextColor(Color.GRAY); break;
            case "CANCELLED": tv.setTextColor(Color.RED); break;
        }
    }

    private void configureNextButton(Button btn, String status) {
        switch (status) {
            case "NEW": btn.setText("Accept"); break;
            case "PREPARING": btn.setText("Ready"); break;
            case "READY": btn.setText("Complete"); break;
            default: btn.setVisibility(View.GONE); break;
        }
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvDate, tvItems, tvTotal, tvStatus;
        Button btnNext, btnCancel;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvDate = itemView.findViewById(R.id.tvOrderDate);
            tvItems = itemView.findViewById(R.id.tvOrderItems);
            tvTotal = itemView.findViewById(R.id.tvOrderTotal);
            tvStatus = itemView.findViewById(R.id.tvOrderStatus);
            btnNext = itemView.findViewById(R.id.btnNextStatus);
            btnCancel = itemView.findViewById(R.id.btnCancelOrder);
        }
    }
}