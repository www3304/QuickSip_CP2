package com.quicksip.cp2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;
    private OnOrderClickListener listener;

    public interface OnOrderClickListener {
        void onOrderAction(Order order, boolean isNext);
    }

    public OrderAdapter(List<Order> orderList, OnOrderClickListener listener) {
        this.orderList = orderList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);

        holder.tvOrderId.setText("Order #" + order.getOrderId());

        if (order.getTimeStamp() != null) {
            if (order.getTimeStamp() instanceof Timestamp) {
                Timestamp ts = (Timestamp) order.getTimeStamp();
                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault());
                holder.tvDate.setText(sdf.format(ts.toDate()));
            }
        }

        String status = order.getStatus() != null ? order.getStatus().toUpperCase() : "NEW";
        holder.tvStatus.setText("Status: " + status);
        setStatusColor(holder.tvStatus, status);

        // ✅ DYNAMIC ROWS
        holder.itemsContainer.removeAllViews();
        if (order.getItems() != null) {
            for (CartItem item : order.getItems()) {
                View row = LayoutInflater.from(holder.itemView.getContext())
                        .inflate(R.layout.item_order_row, holder.itemsContainer, false);

                TextView tvName = row.findViewById(R.id.tvRowName);
                TextView tvDetails = row.findViewById(R.id.tvRowDetails);
                TextView tvPrice = row.findViewById(R.id.tvRowPrice);

                tvName.setText(item.getQuantity() + "x " + item.getDrinkName());

                StringBuilder details = new StringBuilder();
                details.append(item.getSize()).append(", ")
                        .append(item.getSugar()).append(", ")
                        .append(item.getIce());

                if (item.getToppings() != null && !item.getToppings().isEmpty()) {
                    details.append("\n+ ").append(item.getToppings());
                }
                tvDetails.setText(details.toString());

                double unitPrice = item.getFinalPrice();
                if (unitPrice == 0 && item.getBasePrice() > 0) {
                    unitPrice = item.getBasePrice();
                }

                double lineTotal = unitPrice * item.getQuantity();
                tvPrice.setText("RM " + String.format("%.2f", lineTotal));

                holder.itemsContainer.addView(row);
            }
        }

        holder.tvTotal.setText("Total: RM " + String.format("%.2f", order.getTotalPrice()));

        if (listener == null) {
            if(holder.btnNext != null) holder.btnNext.setVisibility(View.GONE);
            if(holder.btnCancel != null) holder.btnCancel.setVisibility(View.GONE);
        } else {
            if(holder.btnNext != null) {
                holder.btnNext.setVisibility(View.VISIBLE);
                configureNextButton(holder.btnNext, status);
                holder.btnNext.setOnClickListener(v -> listener.onOrderAction(order, true));
            }
            if(holder.btnCancel != null) {
                holder.btnCancel.setVisibility(View.VISIBLE);
                holder.btnCancel.setOnClickListener(v -> listener.onOrderAction(order, false));
            }

            if("COMPLETED".equals(status) || "CANCELLED".equals(status)) {
                if(holder.btnNext != null) holder.btnNext.setVisibility(View.GONE);
                if(holder.btnCancel != null) holder.btnCancel.setVisibility(View.GONE);
            }
        }
    }

    private void setStatusColor(TextView tv, String status) {
        switch (status) {
            case "NEW": tv.setTextColor(Color.BLUE); break;
            case "PREPARING": tv.setTextColor(Color.parseColor("#FFA500")); break;
            case "READY": tv.setTextColor(Color.parseColor("#006400")); break;
            case "COMPLETED": tv.setTextColor(Color.GRAY); break;
            case "CANCELLED": tv.setTextColor(Color.RED); break;
        }
    }

    private void configureNextButton(Button btn, String status) {
        switch (status) {
            case "NEW": btn.setText("Accept"); break;
            case "PREPARING": btn.setText("Ready"); break;
            case "READY": btn.setText("Complete"); break;
            default: btn.setVisibility(View.GONE); break;
        }
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvDate, tvTotal, tvStatus;
        LinearLayout itemsContainer; // ✅ New container
        Button btnNext, btnCancel;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvDate = itemView.findViewById(R.id.tvOrderDate);

            // ✅ Find container
            itemsContainer = itemView.findViewById(R.id.itemsContainer);

            tvTotal = itemView.findViewById(R.id.tvOrderTotal);
            tvStatus = itemView.findViewById(R.id.tvOrderStatus);
            btnNext = itemView.findViewById(R.id.btnNextStatus);
            btnCancel = itemView.findViewById(R.id.btnCancelOrder);
        }
    }
}