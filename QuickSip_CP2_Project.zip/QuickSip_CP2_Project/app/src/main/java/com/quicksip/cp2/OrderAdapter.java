package com.quicksip.cp2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.quicksip.cp2.Order;
import com.quicksip.cp2.CartItem;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;

    public interface OnStatusChangeListener {
        void onStatusChange(int position, String newStatus);
        void onCancel(int position);
    }

    private OnStatusChangeListener listener;

    public OrderAdapter(List<Order> orderList, OnStatusChangeListener listener) {
        this.orderList = orderList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {

        Order order = orderList.get(position);

        // Basic fields
        holder.tvOrderId.setText("Order ID: " + order.getOrderId());
        holder.tvOrderTime.setText("Time: " + order.getTimeStamp());
        holder.tvStatus.setText("Status: " + order.getStatus());
        holder.tvPrice.setText("Total: RM " + String.format("%.2f", order.getTotalPrice()));

        // -------------------------------
        // STATUS COLOR LABELS
        // -------------------------------
        switch (order.getStatus()) {
            case "NEW":
                holder.tvStatus.setTextColor(holder.itemView.getContext().getColor(R.color.status_new));
                break;

            case "PREPARING":
                holder.tvStatus.setTextColor(holder.itemView.getContext().getColor(R.color.status_preparing));
                break;

            case "READY":
                holder.tvStatus.setTextColor(holder.itemView.getContext().getColor(R.color.status_ready));
                break;

            case "COMPLETED":
                holder.tvStatus.setTextColor(holder.itemView.getContext().getColor(R.color.status_completed));
                break;
        }

        // -------------------------------
        // EXPANDABLE ORDER DETAILS
        // -------------------------------
        StringBuilder itemsText = new StringBuilder();

        for (CartItem drink : order.getItems()) {
            itemsText.append("• ")
                    .append(drink.getDrinkName())
                    .append(" (")
                    .append(drink.getSize())
                    .append(", Ice ")
                    .append(drink.getIce())
                    .append(", Sugar ")
                    .append(drink.getSugar())
                    .append(")\nToppings: ")
                    .append(drink.getToppings().isEmpty() ? "None" : drink.getToppings())
                    .append("\n\n");
        }

        holder.tvOrderItems.setText(itemsText.toString());

        // Toggle expand/collapse
        holder.itemView.setOnClickListener(v -> {
            if (holder.tvOrderItems.getVisibility() == View.GONE) {
                holder.tvOrderItems.setVisibility(View.VISIBLE);
            } else {
                holder.tvOrderItems.setVisibility(View.GONE);
            }
        });

        // -------------------------------
        // BUTTONS
        // -------------------------------
        holder.btnNext.setOnClickListener(v -> {
            if (listener != null) {
                String newStatus = nextStatus(order.getStatus());
                listener.onStatusChange(position, newStatus);
            }
        });

        holder.btnCancel.setOnClickListener(v -> {
            if (listener != null) listener.onCancel(position);
        });

        if ("COMPLETED".equals(order.getStatus())) {
            holder.btnNext.setEnabled(false);
            holder.btnCancel.setEnabled(false);
            holder.btnNext.setAlpha(0.5f);
            holder.btnCancel.setAlpha(0.5f);
        }
    }

    // ---------------------------------------
    // STATUS TRANSITION LOGIC
    // ---------------------------------------
    private String nextStatus(String current) {
        switch (current) {
            case "NEW": return "PREPARING";
            case "PREPARING": return "READY";
            case "READY": return "COMPLETED";
            default: return "COMPLETED";
        }
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {

        TextView tvOrderId, tvOrderTime, tvStatus, tvPrice, tvOrderItems;
        Button btnNext, btnCancel;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);

            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderTime = itemView.findViewById(R.id.tvOrderTime);
            tvStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvPrice = itemView.findViewById(R.id.tvOrderPrice);
            tvOrderItems = itemView.findViewById(R.id.tvOrderItems);

            btnNext = itemView.findViewById(R.id.btnNextStatus);
            btnCancel = itemView.findViewById(R.id.btnCancelOrder);
        }
    }
}
