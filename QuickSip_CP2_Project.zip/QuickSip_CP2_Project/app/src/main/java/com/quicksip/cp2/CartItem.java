package com.quicksip.cp2;

import java.io.Serializable;

public class CartItem implements Serializable {
    private String drinkName;
    private double basePrice;
    private String size;
    private String sugar;
    private String ice;
    private int quantity;
    private String toppings;

    // Empty constructor for Firestore
    public CartItem() {}

    // Constructor
    public CartItem(String drinkName, double basePrice, String size, String sugar, String ice, int quantity) {
        this.drinkName = drinkName;
        this.basePrice = basePrice;
        this.size = size;
        this.sugar = sugar;
        this.ice = ice;
        this.quantity = quantity;
        this.toppings = ""; // Default empty
    }

    // --- GETTERS & SETTERS ---
    public String getDrinkName() { return drinkName; }
    public void setDrinkName(String drinkName) { this.drinkName = drinkName; }

    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getSugar() { return sugar; }
    public void setSugar(String sugar) { this.sugar = sugar; }

    public String getIce() { return ice; }
    public void setIce(String ice) { this.ice = ice; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getToppings() { return toppings == null ? "" : toppings; }
    public void setToppings(String toppings) { this.toppings = toppings; }

    // 🔥 FIXED CALCULATION METHOD
    public double getFinalPrice() {
        double price = basePrice;

        // 1. Add Size Cost
        if ("Large".equalsIgnoreCase(size)) {
            price += 1.00;
        }

        // 2. Add Toppings Cost
        // We check if the 'toppings' string contains the keywords
        if (toppings != null && !toppings.isEmpty()) {
            if (toppings.contains("Pearl")) {
                price += 1.50;
            }
            if (toppings.contains("Pudding")) {
                price += 1.50;
            }
            if (toppings.contains("Jelly")) {
                price += 1.00;
            }
        }

        return price;
    }
}