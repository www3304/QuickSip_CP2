package com.quicksip.cp2;

import com.google.firebase.firestore.Exclude; // Import this
import com.google.firebase.firestore.PropertyName;
import java.util.List;

public class CartItem {
    private String drinkName;
    private double price;
    private double basePrice;
    private int quantity;
    private String size;
    private String sugar;
    private String ice;
    private String toppings;
    private int imageResId;
    private List<String> categories;

    public CartItem() {
        // Empty constructor needed for Firestore
    }

    public CartItem(String drinkName, double price, double basePrice, int quantity, String size, String sugar, String ice, String toppings, int imageResId, List<String> categories) {
        this.drinkName = drinkName;
        this.price = price;
        this.basePrice = basePrice;
        this.quantity = quantity;
        this.size = size;
        this.sugar = sugar;
        this.ice = ice;
        this.toppings = toppings;
        this.imageResId = imageResId;
        this.categories = categories;
    }

    // --- GETTERS & SETTERS ---

    // Maps "drinkName" in Java to "name" in Firestore automatically due to method name
    @PropertyName("name")
    public String getName() { return drinkName; }

    @PropertyName("name")
    public void setName(String drinkName) { this.drinkName = drinkName; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getSugar() { return sugar; }
    public void setSugar(String sugar) { this.sugar = sugar; }

    public String getIce() { return ice; }
    public void setIce(String ice) { this.ice = ice; }

    public String getToppings() { return toppings; }
    public void setToppings(String toppings) { this.toppings = toppings; }

    public int getImageResId() { return imageResId; }
    public void setImageResId(int imageResId) { this.imageResId = imageResId; }

    public List<String> getCategories() { return categories; }
    public void setCategories(List<String> categories) { this.categories = categories; }

    // --- HELPER METHODS ---

    @Exclude // <--- CRITICAL FIX: Prevents "No setter/field for finalPrice" error
    public double getFinalPrice() { return price; }
}