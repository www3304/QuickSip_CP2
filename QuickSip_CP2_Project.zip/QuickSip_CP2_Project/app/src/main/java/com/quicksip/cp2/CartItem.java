package com.quicksip.cp2;

import java.io.Serializable;

public class CartItem implements Serializable {

    private String drinkName;
    private double basePrice;
    private int quantity;
    private String size;
    private String ice;
    private String sugar;
    private String toppings;
    private double finalPrice;
    private int imageResId;

    // 🔥 REQUIRED empty constructor for Firestore
    public CartItem() {}

    // ✅ FULL CONSTRUCTOR (9 Parameters)
    public CartItem(String drinkName, double basePrice, int quantity, String size, String ice, String sugar, String toppings, double finalPrice, int imageResId) {
        this.drinkName = drinkName;
        this.basePrice = basePrice;
        this.quantity = quantity;
        this.size = size;
        this.ice = ice;
        this.sugar = sugar;
        this.toppings = toppings;
        this.finalPrice = finalPrice;
        this.imageResId = imageResId;
    }

    // -------- GETTERS & SETTERS --------
    public String getDrinkName() { return drinkName; }
    public void setDrinkName(String drinkName) { this.drinkName = drinkName; }

    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getIce() { return ice; }
    public void setIce(String ice) { this.ice = ice; }

    public String getSugar() { return sugar; }
    public void setSugar(String sugar) { this.sugar = sugar; }

    public String getToppings() { return toppings; }
    public void setToppings(String toppings) { this.toppings = toppings; }

    public double getFinalPrice() { return finalPrice; }
    public void setFinalPrice(double finalPrice) { this.finalPrice = finalPrice; }

    public int getImageResId() { return imageResId; }
    public void setImageResId(int imageResId) { this.imageResId = imageResId; }

    public void increaseQty() {
        this.quantity++;
    }
}