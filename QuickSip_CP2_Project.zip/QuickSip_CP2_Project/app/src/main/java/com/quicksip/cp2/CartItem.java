package com.quicksip.cp2;

import java.util.List;

public class CartItem {
    private String drinkName;
    private double price;
    private double basePrice;
    private int quantity;
    private String size;
    private String sugar;
    private String ice;
    private String toppings;
    private int imageResId;
    private List<String> categories;

    public CartItem() {
        // Empty constructor needed for Firestore
    }

    public CartItem(String drinkName, double price, double basePrice, int quantity, String size, String sugar, String ice, String toppings, int imageResId, List<String> categories) {
        this.drinkName = drinkName;
        this.price = price;
        this.basePrice = basePrice;
        this.quantity = quantity;
        this.size = size;
        this.sugar = sugar;
        this.ice = ice;
        this.toppings = toppings;
        this.imageResId = imageResId;
        this.categories = categories;
    }

    // --- GETTERS ---
    public String getName() { return drinkName; }
    public double getPrice() { return price; }
    public double getBasePrice() { return basePrice; }
    public int getQuantity() { return quantity; }
    public String getSize() { return size; }
    public String getSugar() { return sugar; }
    public String getIce() { return ice; }
    public String getToppings() { return toppings; }
    public int getImageResId() { return imageResId; }
    public List<String> getCategories() { return categories; }

    public void setName(String drinkName) { this.drinkName = drinkName; }
    public void setPrice(double price) { this.price = price; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setSize(String size) { this.size = size; }
    public void setSugar(String sugar) { this.sugar = sugar; }
    public void setIce(String ice) { this.ice = ice; }
    public void setToppings(String toppings) { this.toppings = toppings; }
    public void setImageResId(int imageResId) { this.imageResId = imageResId; }
    public void setCategories(List<String> categories) { this.categories = categories; }

    // Helper
    public double getFinalPrice() { return price; }
}