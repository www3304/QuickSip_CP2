package com.quicksip.cp2;

public class CartItem {

    private String drinkName;
    private double basePrice;
    private String size;
    private String ice;
    private String sugar;
    private String toppings;
    private int quantity;
    private int imageResId;
    private double finalPrice;

    // 🔥 REQUIRED empty constructor (Firestore)
    public CartItem() {}

    public CartItem(String drinkName, double basePrice,
                    String size, String ice, String sugar,
                    String toppings, double finalPrice, int imageResId) {

        this.drinkName = drinkName;
        this.basePrice = basePrice;
        this.size = size;
        this.ice = ice;
        this.sugar = sugar;
        this.toppings = toppings;
        this.finalPrice = finalPrice;
        this.imageResId = imageResId;
        this.quantity = 1;
    }

    // -------- QUANTITY CONTROL --------

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void increaseQty() {
        quantity++;
    }

    public void decreaseQty() {
        if (quantity > 1) {
            quantity--;
        }
    }

    // -------- GETTERS & SETTERS --------

    public String getDrinkName() { return drinkName; }
    public void setDrinkName(String drinkName) { this.drinkName = drinkName; }

    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getIce() { return ice; }
    public void setIce(String ice) { this.ice = ice; }

    public String getSugar() { return sugar; }
    public void setSugar(String sugar) { this.sugar = sugar; }

    public String getToppings() { return toppings; }
    public void setToppings(String toppings) { this.toppings = toppings; }

    public int getImageResId() { return imageResId; }
    public void setImageResId(int imageResId) { this.imageResId = imageResId; }

    public double getFinalPrice() { return finalPrice; }
    public void setFinalPrice(double finalPrice) { this.finalPrice = finalPrice; }
}
