package com.quicksip.cp2;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomerHomeActivity extends AppCompatActivity {

    private RecyclerView drinkRecycler;
    private DrinkAdapter adapter;
    private List<DrinkItem> drinkList;
    private TextView tvCollectMethod;
    private LinearLayout categoryContainer;
    private String selectedCategory = "All"; // Default

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);

        drinkRecycler = findViewById(R.id.drinkRecycler);
        drinkRecycler.setLayoutManager(new LinearLayoutManager(this));

        // ✅ 1. UPDATE DATA WITH CATEGORIES
        drinkList = new ArrayList<>();
        drinkList.add(new DrinkItem("Classic Milk Tea", 6.50, R.drawable.milk_tea, "Milk Tea"));
        drinkList.add(new DrinkItem("Brown Sugar Boba", 7.90, R.drawable.brown_sugar, "Milk Tea"));
        drinkList.add(new DrinkItem("Matcha Latte", 8.50, R.drawable.matcha_latte, "Matcha"));
        drinkList.add(new DrinkItem("Caramel Coffee", 7.20, R.drawable.caramel_coffee, "Coffee"));
        // Add dummy items for other categories to test filter
        drinkList.add(new DrinkItem("Hazelnut Latte", 8.00, R.drawable.caramel_coffee, "Latte"));
        drinkList.add(new DrinkItem("Mango Refresher", 5.50, R.drawable.matcha_latte, "Refresher"));
        drinkList.add(new DrinkItem("Mineral Water", 2.00, R.drawable.milk_tea, "Bottled"));

        adapter = new DrinkAdapter(drinkList, item -> {
            Intent intent = new Intent(CustomerHomeActivity.this, DrinkCustomizeActivity.class);
            intent.putExtra("drinkName", item.getName());
            intent.putExtra("drinkPrice", item.getPrice());
            intent.putExtra("drinkImage", item.getImageResId());
            startActivity(intent);
        });
        drinkRecycler.setAdapter(adapter);

        // ✅ 2. SETUP CATEGORIES
        categoryContainer = findViewById(R.id.categoryContainer);
        setupCategories();

        // 3. SEARCH
        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // 4. COLLECT METHOD
        tvCollectMethod = findViewById(R.id.tvCollectMethod);
        tvCollectMethod.setOnClickListener(v -> showCollectMethodDialog());

        // 5. NAV
        findViewById(R.id.btnTopCart).setOnClickListener(v -> startActivity(new Intent(this, CartActivity.class)));
        findViewById(R.id.navMyOrders).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerOrdersActivity.class));
            overridePendingTransition(0, 0); // Remove animation for smooth nav
        });
        findViewById(R.id.navProfile).setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
            overridePendingTransition(0, 0);
        });
    }

    private void setupCategories() {
        String[] categories = {"All", "Milk Tea", "Coffee", "Latte", "Matcha", "Refresher", "Bottled"};

        for (String cat : categories) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(14);
            chip.setPadding(32, 16, 32, 16);
            chip.setGravity(Gravity.CENTER);

            // Margin
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 16, 0);
            chip.setLayoutParams(params);

            // Click Logic
            chip.setOnClickListener(v -> {
                selectedCategory = cat;
                updateCategoryUI();
                filterByCategory(cat);
            });

            categoryContainer.addView(chip);
        }
        updateCategoryUI(); // Set initial state
    }

    private void updateCategoryUI() {
        for (int i = 0; i < categoryContainer.getChildCount(); i++) {
            TextView child = (TextView) categoryContainer.getChildAt(i);
            if (child.getText().toString().equals(selectedCategory)) {
                child.setBackgroundResource(R.drawable.circle_green_bg); // Selected: Green
                child.setTextColor(Color.WHITE);
                child.setTypeface(null, android.graphics.Typeface.BOLD);
            } else {
                child.setBackgroundResource(R.drawable.input_bg_grab); // Unselected: Gray/White
                child.setTextColor(Color.BLACK);
                child.setTypeface(null, android.graphics.Typeface.NORMAL);
            }
        }
    }

    private void filterByCategory(String category) {
        List<DrinkItem> filtered = new ArrayList<>();
        if (category.equals("All")) {
            filtered.addAll(drinkList);
        } else {
            for (DrinkItem item : drinkList) {
                if (item.getCategory().equals(category)) {
                    filtered.add(item);
                }
            }
        }
        adapter.filterList(filtered);
    }

    private void filter(String text) {
        // Simple search that ignores category for now (or you can combine them)
        List<DrinkItem> filteredList = new ArrayList<>();
        for (DrinkItem item : drinkList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.filterList(filteredList);
    }

    private void showCollectMethodDialog() {
        String[] options = {"Pick-Up at Counter", "Takeaway", "Dine-in"};
        new AlertDialog.Builder(this)
                .setTitle("Select Collect Method")
                .setItems(options, (dialog, which) -> tvCollectMethod.setText(options[which]))
                .show();
    }
}