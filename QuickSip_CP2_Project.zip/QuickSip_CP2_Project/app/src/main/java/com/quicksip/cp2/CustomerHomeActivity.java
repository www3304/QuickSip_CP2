package com.quicksip.cp2;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomerHomeActivity extends AppCompatActivity {

    private RecyclerView drinkRecycler;
    private DrinkAdapter adapter;
    private List<DrinkItem> drinkList;
    private TextView tvCollectMethod;
    private LinearLayout categoryContainer;
    private String selectedCategory = "All"; // Default

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);

        drinkRecycler = findViewById(R.id.drinkRecycler);
        drinkRecycler.setLayoutManager(new LinearLayoutManager(this));

        // 1. UPDATE DATA
        drinkList = new ArrayList<>();

        // --- TEA CATEGORY ---
        drinkList.add(new DrinkItem("Boba Tea", "Classic milk tea served with chewy tapioca pearls.", 7.50, R.drawable.boba_tea, "Tea"));
        drinkList.add(new DrinkItem("Hokkaido Milk Tea", "Rich creamy milk tea with a distinct caramel flavor.", 8.90, R.drawable.hokkaido_milk_tea, "Tea"));
        drinkList.add(new DrinkItem("Jasmine Milk Tea", "Fragrant jasmine tea blended with smooth milk.", 7.90, R.drawable.jasmine_milk_tea, "Tea"));
        drinkList.add(new DrinkItem("Masala Chai", "Spiced tea brewed with aromatic Indian spices.", 6.50, R.drawable.masala_chai, "Tea"));
        drinkList.add(new DrinkItem("Taro Milk Tea", "Sweet and creamy purple taro goodness.", 8.50, R.drawable.taro_milk_tea, "Tea"));
        drinkList.add(new DrinkItem("Tea Latte", "Freshly brewed tea topped with steamed milk foam.", 9.00, R.drawable.tea_latte, "Tea", "Latte"));

        // --- MATCHA CATEGORY ---
        drinkList.add(new DrinkItem("Matcha Milk Tea", "Premium Japanese matcha whisked with sweet milk.", 8.90, R.drawable.matcha_milk_tea, "Matcha", "Tea"));
        drinkList.add(new DrinkItem("Matcha Latte", "Smooth matcha green tea layered with steamed milk.", 9.50, R.drawable.matcha_latte, "Matcha", "Latte"));
        drinkList.add(new DrinkItem("Mocha Matcha Latte", "A unique fusion of chocolate, coffee, and matcha.", 10.50, R.drawable.mocha_matcha_latte, "Matcha", "Latte"));
        drinkList.add(new DrinkItem("Blueberry Lemon Fizz", "Sparkling matcha refresher with blueberry and lemon.", 8.50, R.drawable.blueberry_lemon_matcha_fizz, "Matcha", "Refresher"));
        drinkList.add(new DrinkItem("Cold Brew Matcha", "Pure matcha steeped cold for a smooth, clean taste.", 7.50, R.drawable.cold_brew_matcha, "Matcha"));
        drinkList.add(new DrinkItem("Iced Hibiscus Matcha", "Floral hibiscus tea blended with earthy matcha.", 8.00, R.drawable.iced_hibiscus_matcha, "Matcha"));

        // --- REFRESHER CATEGORY ---
        drinkList.add(new DrinkItem("Iced White Tea", "Delicate white tea served ice-cold and refreshing.", 6.50, R.drawable.iced_white_tea, "Refresher", "Tea"));
        drinkList.add(new DrinkItem("Lemonade", "Zesty fresh lemon juice with a touch of sweetness.", 5.50, R.drawable.lemonade, "Refresher"));
        drinkList.add(new DrinkItem("Cherry Limeade", "Sweet cherry meets tangy lime in a sparkling cooler.", 7.50, R.drawable.refreshing_cherry_limeade, "Refresher"));
        drinkList.add(new DrinkItem("Strawberry Soda", "Bubbly soda infused with real strawberry fruit syrup.", 6.50, R.drawable.strawberry_soda, "Refresher"));
        drinkList.add(new DrinkItem("Guava White Tea", "Tropical guava flavors blended with light white tea.", 8.50, R.drawable.tasty_guava_white_tea_lemonade, "Refresher"));

        // --- COFFEE ---
        drinkList.add(new DrinkItem("Americano", "Bold espresso shots topped with hot water.", 5.50, R.drawable.americano, "Coffee"));
        drinkList.add(new DrinkItem("Cappuccino", "Espresso with equal parts steamed milk and foam.", 8.50, R.drawable.cappuccino, "Coffee"));
        drinkList.add(new DrinkItem("Espresso", "A concentrated shot of rich, robust coffee.", 4.50, R.drawable.espresso, "Coffee"));

        // --- LATTE ---
        drinkList.add(new DrinkItem("Cafe Latte", "Espresso with steamed milk and a thin layer of foam.", 9.00, R.drawable.cafe_latte, "Coffee", "Latte"));
        drinkList.add(new DrinkItem("Caramel Macchiato", "Espresso marked with caramel and vanilla milk.", 10.50, R.drawable.caramel_macchiato, "Coffee", "Latte"));

        // --- BOTTLED ---
        drinkList.add(new DrinkItem("Evian Water (500ml)", "Pure natural mineral water from the French Alps.", 3.50, R.drawable.evian_500ml, "Bottled"));
        drinkList.add(new DrinkItem("Evian Water (750ml)", "Pure natural mineral water in a larger bottle.", 5.50, R.drawable.evian_750ml, "Bottled"));

        // Setup Adapter
        adapter = new DrinkAdapter(drinkList, item -> {
            Intent intent = new Intent(CustomerHomeActivity.this, DrinkCustomizeActivity.class);
            intent.putExtra("drinkName", item.getName());
            intent.putExtra("drinkPrice", item.getPrice());
            intent.putExtra("drinkImage", item.getImageResId());

            // Pass the categories list as a String Array
            List<String> cats = item.getCategories();
            intent.putExtra("drinkCategories", cats.toArray(new String[0]));

            startActivity(intent);
        });
        drinkRecycler.setAdapter(adapter);

        // 2. SETUP CATEGORIES
        categoryContainer = findViewById(R.id.categoryContainer);
        setupCategories();

        // 3. SEARCH & LISTENERS
        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        tvCollectMethod = findViewById(R.id.tvCollectMethod);
        tvCollectMethod.setOnClickListener(v -> showCollectMethodDialog());

        findViewById(R.id.btnTopCart).setOnClickListener(v -> startActivity(new Intent(this, CartActivity.class)));
        findViewById(R.id.navMyOrders).setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerOrdersActivity.class));
            overridePendingTransition(0, 0);
        });
        findViewById(R.id.navProfile).setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
            overridePendingTransition(0, 0);
        });
    }

    private void setupCategories() {
        String[] categories = {"All", "Tea", "Coffee", "Latte", "Matcha", "Refresher", "Bottled"};

        for (String cat : categories) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(14);
            chip.setPadding(32, 16, 32, 16);
            chip.setGravity(Gravity.CENTER);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 16, 0);
            chip.setLayoutParams(params);

            chip.setOnClickListener(v -> {
                selectedCategory = cat;
                updateCategoryUI();
                filterByCategory(cat);
            });

            categoryContainer.addView(chip);
        }
        updateCategoryUI();
    }

    private void updateCategoryUI() {
        for (int i = 0; i < categoryContainer.getChildCount(); i++) {
            TextView child = (TextView) categoryContainer.getChildAt(i);
            if (child.getText().toString().equals(selectedCategory)) {
                child.setBackgroundResource(R.drawable.circle_green_bg);
                child.setTextColor(Color.WHITE);
                child.setTypeface(null, android.graphics.Typeface.BOLD);
            } else {
                child.setBackgroundResource(R.drawable.input_bg_grab);
                child.setTextColor(Color.BLACK);
                child.setTypeface(null, android.graphics.Typeface.NORMAL);
            }
        }
    }

    private void filterByCategory(String category) {
        List<DrinkItem> filtered = new ArrayList<>();
        if (category.equals("All")) {
            filtered.addAll(drinkList);
        } else {
            for (DrinkItem item : drinkList) {
                if (item.hasCategory(category)) {
                    filtered.add(item);
                }
            }
        }
        adapter.filterList(filtered);
    }

    private void filter(String text) {
        List<DrinkItem> filteredList = new ArrayList<>();
        for (DrinkItem item : drinkList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        adapter.filterList(filteredList);
    }

    private void showCollectMethodDialog() {
        String[] options = {"Pick-Up at Counter", "Takeaway", "Dine-in"};
        new AlertDialog.Builder(this)
                .setTitle("Select Collect Method")
                .setItems(options, (dialog, which) -> tvCollectMethod.setText(options[which]))
                .show();
    }
}