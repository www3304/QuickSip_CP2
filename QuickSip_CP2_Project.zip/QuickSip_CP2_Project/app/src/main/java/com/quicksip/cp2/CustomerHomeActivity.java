package com.quicksip.cp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class CustomerHomeActivity extends AppCompatActivity {

    private RecyclerView menuRecycler;
    private DrinkAdapter adapter;
    private List<DrinkItem> drinkList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);

        // -------------------------------
        // TOOLBAR (TOP BAR)
        // -------------------------------
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // -------------------------------
        // MENU LIST
        // -------------------------------
        menuRecycler = findViewById(R.id.menuRecycler);
        menuRecycler.setLayoutManager(new LinearLayoutManager(this));

        drinkList = new ArrayList<>();
        drinkList.add(new DrinkItem("Classic Milk Tea", 6.50, R.drawable.milk_tea));
        drinkList.add(new DrinkItem("Brown Sugar Boba", 7.90, R.drawable.brown_sugar));
        drinkList.add(new DrinkItem("Matcha Latte", 8.50, R.drawable.matcha_latte));
        drinkList.add(new DrinkItem("Caramel Coffee", 7.20, R.drawable.caramel_coffee));

        adapter = new DrinkAdapter(drinkList, item -> {
            Intent intent = new Intent(CustomerHomeActivity.this, DrinkCustomizeActivity.class);
            intent.putExtra("drinkName", item.getName());
            intent.putExtra("drinkPrice", item.getPrice());
            intent.putExtra("drinkImage", item.getImageResId());
            startActivity(intent);
        });

        menuRecycler.setAdapter(adapter);

        // -------------------------------
        // VIEW CART
        // -------------------------------
        Button btnViewCart = findViewById(R.id.btnViewCart);
        btnViewCart.setOnClickListener(v -> {
            startActivity(new Intent(this, CartActivity.class));
        });

        // -------------------------------
        // MY ORDERS
        // -------------------------------
        Button btnMyOrders = findViewById(R.id.btnMyOrders);
        btnMyOrders.setOnClickListener(v -> {
            startActivity(new Intent(this, CustomerOrdersActivity.class));
        });
    }

    // -------------------------------
    // TOOLBAR MENU
    // -------------------------------
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_customer_home, menu);
        return true;
    }

    // -------------------------------
    // LOGOUT ACTION
    // -------------------------------
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {

            FirebaseAuth.getInstance().signOut();

            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
