package com.quicksip.cp2;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomerHomeActivity extends AppCompatActivity {

    private RecyclerView drinkRecycler;
    private DrinkAdapter adapter;
    private List<DrinkItem> drinkList;
    private TextView tvCollectMethod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);

        // ---------------------------------------------------------
        // 1. SETUP RECYCLERVIEW
        // ---------------------------------------------------------
        drinkRecycler = findViewById(R.id.drinkRecycler);
        drinkRecycler.setLayoutManager(new LinearLayoutManager(this));

        drinkList = new ArrayList<>();
        drinkList.add(new DrinkItem("Classic Milk Tea", 6.50, R.drawable.milk_tea));
        drinkList.add(new DrinkItem("Brown Sugar Boba", 7.90, R.drawable.brown_sugar));
        drinkList.add(new DrinkItem("Matcha Latte", 8.50, R.drawable.matcha_latte));
        drinkList.add(new DrinkItem("Caramel Coffee", 7.20, R.drawable.caramel_coffee));

        adapter = new DrinkAdapter(drinkList, item -> {
            Intent intent = new Intent(CustomerHomeActivity.this, DrinkCustomizeActivity.class);
            intent.putExtra("drinkName", item.getName());
            intent.putExtra("drinkPrice", item.getPrice());
            intent.putExtra("drinkImage", item.getImageResId());
            startActivity(intent);
        });
        drinkRecycler.setAdapter(adapter);

        // ---------------------------------------------------------
        // 2. SEARCH FUNCTIONALITY
        // ---------------------------------------------------------
        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // ---------------------------------------------------------
        // 3. COLLECT METHOD (Dropdown Logic)
        // ---------------------------------------------------------
        tvCollectMethod = findViewById(R.id.tvCollectMethod);
        tvCollectMethod.setOnClickListener(v -> showCollectMethodDialog());

        // ---------------------------------------------------------
        // 4. NAVIGATION LISTENERS
        // ---------------------------------------------------------

        // Cart Button (Top Right)
        findViewById(R.id.btnTopCart).setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class))
        );

        // Bottom Nav: My Orders
        findViewById(R.id.navMyOrders).setOnClickListener(v ->
                startActivity(new Intent(this, CustomerOrdersActivity.class))
        );

        // Bottom Nav: Profile
        findViewById(R.id.navProfile).setOnClickListener(v ->
                startActivity(new Intent(this, ProfileActivity.class))
        );
    }

    // Helper: Filter Logic
    private void filter(String text) {
        List<DrinkItem> filteredList = new ArrayList<>();
        for (DrinkItem item : drinkList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        // You need to create this method in DrinkAdapter (see Step 5)
        adapter.filterList(filteredList);
    }

    // Helper: Collect Method Dialog
    private void showCollectMethodDialog() {
        String[] options = {"Pick-Up at Counter", "Takeaway", "Dine-in"};
        new AlertDialog.Builder(this)
                .setTitle("Select Collect Method")
                .setItems(options, (dialog, which) -> {
                    tvCollectMethod.setText(options[which]);
                })
                .show();
    }
}